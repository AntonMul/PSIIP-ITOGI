
<html >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> </title>
</head>
<body>
<div>
<form action="obrab.php" method="POST">
<form action="obrab.php" method="post">
<p><label>Логин<br>
<input placeholder="Логин" name="IMI" size="25" type="text"></label></p>
<p><label> Пароль </label></p>
 <input placeholder="Пароль" size="25" name="kont" type="password"></label></p> 
 <p><input id="remember-checkbox" type="checkbox"> Запомнить</p>
    <input type="submit" name="submit" value="Вход" />

   </form>   
 </div>
</form>
<div>
</div>




<bid>


</div>



</body>
</html>








