<?php

echo $_POST['IMI'];
echo $_REQUEST['kont'];

    $data = file_get_contents('kop.txt');

    var_dump($data);

?>