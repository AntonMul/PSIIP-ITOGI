<?php
$link=mysqli_connect("localhost", "root", "root", "kyrsach");
if(isset($_POST['submit']))
{
    // Вытаскиваем из БД запись, у которой логин равняеться введенному
    $query = mysqli_query($link,"Select id, ФИО,логин, пароль FROM Rgusers WHERE логин='".mysqli_real_escape_string($link,$_POST['login'])."' LIMIT 1");
    $data = mysqli_fetch_assoc($query);
    

    // Сравниваем пароли
    if($data['пароль'] === ($_POST['password']))
    {
        
        
         // Ставим куки
        setcookie("id", $data['id'], time()+60*60*24*30, "/");
        setcookie("FIO",$data['ФИО'], time()+60*60*24*30,"/");
        setcookie("login",$data['логин'], time()+60*60*24*30, "/");
        
        $message= "Вход выполнен";
        header("Location:test.php");
        exit();
    }
    else
    {
        echo "Вы ввели неправильный логин/пароль";
    }
}
?>


<form method="POST">
<h1>Авторизация</h1>
<p>Логин</p> 
<input name="login" type="text" required><br>
<p>Пароль</p>
<input name="password" type="password" required><br>
<p></p>
<input name="submit" type="submit" value="Вход">
<p><a href="/reg.php">Регистрация</p>
</form>