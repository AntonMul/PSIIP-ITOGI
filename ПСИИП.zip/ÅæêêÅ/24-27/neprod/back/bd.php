<?php
$db = new PDO(dsn:"mysql:host=localhost;dbname=neprod", username:"root", passwd: "root");
$info =[];
if ($query = $db->query(statement 'SELECT * FROM info'))
{
    $info = $query->fetchAll(feth_style PDO::FETCH_ASSOC);
}
 else
{
    print_r($db->errorInfo())
}
?>