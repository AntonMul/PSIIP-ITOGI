<?php
    $user = $_COOKIE['login'];
    
    echo "<h2>"."Личный кабинет"."</h2>";

    echo "<div>";
    echo "<div>";
        echo "<div>"."Логин пользователя: ".$_COOKIE['login']."</div>";
    echo "<div>"."ФИО пользователя:".$_COOKIE['FIO']."</div>";
    echo "<div>"."Код пользователя:".$_COOKIE['id']."</div>";
    echo "</div>";
    echo "</div>";
    if(isset($_POST['submit']))
    {
        setcookie("FIO","");
        setcookie("login","");
        setcookie("id","");
        header("Location:/test.php");

    }  
?>

<form method="POST">
    
    <input type="submit" class="btn" name="submit" value = "Выход">
</form>