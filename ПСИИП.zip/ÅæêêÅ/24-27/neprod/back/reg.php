<?php
$link=mysqli_connect("localhost", "root", "root", "kyrsach");
if(isset($_POST['submit']))
{
    $err=[];

    {
        if(!preg_match("/^[a-zA-Z0-9]+$/",$_POST['login']))
        {
            $err[]="Ошибка1";
        }

        if(strlen($_POST['login'])<3 or strlen($_POST['login'])>30)
        {
            $err[]="Ошибка2";
        }

        $query = mysqli_query($link,"Select id From Rgusers
        Where логин='".mysqli_real_escape_string($link,$_POST['login'])."'");
        if(mysqli_num_rows($query)>0)
        {
            $err[]="Уже существует";
        }

        if(count($err)==0)
        {
            $fio=$_POST['FIO'];
            $login=$_POST['login'];
            $password=trim($_POST['password']);
            mysqli_query($link,"Insert into RGusers set Логин='".$login."', Пароль='".$password."', ФИО='".$fio."'");
            echo "Зарегbстрированы";
            header("Location:autr.php");
            exit();
        }
        else
        {
            print "<b>Вознкили ошибки:</b><br>";
            foreach($err As $error)
            {
                print $error."<br>";
            }
        }
    }
}
?>

<form method="POST">
<h1>Регистрация</h1>
<p>ФИО</p>
<input name="FIO" type="text" required><br>
<p>Логин</p> 
<input name="login" type="text" required><br>
<p>Пароль</p>
<input name="password" type="password" required><br>
<p></p>
<input name="submit" type="submit" value="Зарегистрироваться">
<p><a href="/autr.php">Авторизация</p>
</form>