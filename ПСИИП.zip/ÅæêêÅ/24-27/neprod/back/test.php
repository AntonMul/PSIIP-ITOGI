
<?php
 $msg = $_COOKIE["login"];
 if($msg!=null)
 {   
     echo "<li=class'cabin'>"."<a href='cab.php' class='cabin'>".$msg."<a>"."</li>";
 } ?>
 

<!DOCTYPE html><html>
    <head><meta charset="utf-8" /><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="style.css">
    <!--metatextblock--><title>NePROD - товары для бизнеса</title><meta property="og:url" content="https://combasketteam.ru/page33098977.html" /><meta property="og:title" content="NePROD" /><meta property="og:description" content="" /><meta property="og:type" content="website" /><link rel="canonical" href="https://combasketteam.ru/page33098977.html"><!--/metatextblock--><meta name="format-detection" content="telephone=no" /><meta http-equiv="x-dns-prefetch-control" content="on"><link rel="dns-prefetch" href="https://ws.tildacdn.com"><link rel="shortcut icon" href="images/tild3438-3731-4133-b061-623535313536__favicon_1.ico" type="image/x-icon" /><!-- Assets --><script src="https://neo.tildacdn.com/js/tilda-fallback-1.0.min.js" charset="utf-8" async></script><link rel="stylesheet" href="css/tilda-grid-3.0.min.css" type="text/css" media="all" onerror="this.loaderr='y';"/><link rel="stylesheet" href="css/tilda-blocks-page33098977.min.css?t=1673221440" type="text/css" media="all" onerror="this.loaderr='y';" /><link rel="stylesheet" href="css/tilda-animation-2.0.min.css" type="text/css" media="all" onerror="this.loaderr='y';" /><link rel="stylesheet" href="css/tilda-menusub-1.0.min.css" type="text/css" media="print" onload="this.media='all';" onerror="this.loaderr='y';" /><noscript><link rel="stylesheet" href="css/tilda-menusub-1.0.min.css" type="text/css" media="all" /></noscript><link rel="stylesheet" href="css/tilda-forms-1.0.min.css" type="text/css" media="all" onerror="this.loaderr='y';" /><link rel="stylesheet" href="css/tilda-popup-1.1.min.css" type="text/css" media="print" onload="this.media='all';" onerror="this.loaderr='y';" /><noscript><link rel="stylesheet" href="css/tilda-popup-1.1.min.css" type="text/css" media="all" /></noscript><script type="text/javascript">(function (d) {
if (!d.visibilityState) {
var s = d.createElement('script');
s.src = 'js/tilda-polyfill-1.0.min.js';
d.getElementsByTagName('head')[0].appendChild(s);
}
})(document);
function t_onReady(func) {
if (document.readyState != 'loading') {
func();
} else {
document.addEventListener('DOMContentLoaded', func);
}
}
function t_onFuncLoad(funcName, okFunc, time) {
if (typeof window[funcName] === 'function') {
okFunc();
} else {
setTimeout(function() {
t_onFuncLoad(funcName, okFunc, time);
},(time || 100));
}
}function t_throttle(fn, threshhold, scope) {return function () {fn.apply(scope || this, arguments);};}function t396_initialScale(t){var e=document.getElementById("rec"+t);if(e){var r=e.querySelector(".t396__artboard");if(r){var a,i=document.documentElement.clientWidth,l=[],d=r.getAttribute("data-artboard-screens");if(d){d=d.split(",");for(var o=0;o<d.length;o++)l[o]=parseInt(d[o],10)}else l=[320,480,640,960,1200];for(o=0;o<l.length;o++){var n=l[o];n<=i&&(a=n)}var g="edit"===window.allrecords.getAttribute("data-tilda-mode"),u="center"===t396_getFieldValue(r,"valign",a,l),c="grid"===t396_getFieldValue(r,"upscale",a,l),t=t396_getFieldValue(r,"height_vh",a,l),f=t396_getFieldValue(r,"height",a,l),e=!!window.opr&&!!window.opr.addons||!!window.opera||-1!==navigator.userAgent.indexOf(" OPR/");if(!g&&u&&!c&&!t&&f&&!e){for(var s=parseFloat((i/a).toFixed(3)),_=[r,r.querySelector(".t396__carrier"),r.querySelector(".t396__filter")],o=0;o<_.length;o++)_[o].style.height=parseInt(f,10)*s+"px";for(var h=r.querySelectorAll(".t396__elem"),o=0;o<h.length;o++)h[o].style.zoom=s}}}}function t396_getFieldValue(t,e,r,a){var i=a[a.length-1],l=r===i?t.getAttribute("data-artboard-"+e):t.getAttribute("data-artboard-"+e+"-res-"+r);if(!l)for(var d=0;d<a.length;d++){var o=a[d];if(!(o<=r)&&(l=o===i?t.getAttribute("data-artboard-"+e):t.getAttribute("data-artboard-"+e+"-res-"+o)))break}return l}</script><script src="js/jquery-1.10.2.min.js" charset="utf-8" onerror="this.loaderr='y';"></script> <script src="js/tilda-scripts-3.0.min.js" charset="utf-8" defer onerror="this.loaderr='y';"></script><script src="js/tilda-blocks-page33098977.min.js?t=1673221440" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/lazyload-1.3.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-animation-2.0.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-menusub-1.0.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-menu-1.0.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-zero-1.1.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-popup-1.0.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-forms-1.0.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-animation-sbs-1.0.beta.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-zero-scale-1.0.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-events-1.0.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script type="text/javascript">window.dataLayer = window.dataLayer || [];</script><script type="text/javascript">(function () {
if((/bot|google|yandex|baidu|bing|msn|duckduckbot|teoma|slurp|crawler|spider|robot|crawling|facebook/i.test(navigator.userAgent))===false && typeof(sessionStorage)!='undefined' && sessionStorage.getItem('visited')!=='y' && document.visibilityState){
var style=document.createElement('style');
style.type='text/css';
style.innerHTML='@media screen and (min-width: 980px) {.t-records {opacity: 0;}.t-records_animated {-webkit-transition: opacity ease-in-out .2s;-moz-transition: opacity ease-in-out .2s;-o-transition: opacity ease-in-out .2s;transition: opacity ease-in-out .2s;}.t-records.t-records_visible {opacity: 1;}}';
document.getElementsByTagName('head')[0].appendChild(style);
function t_setvisRecs(){
var alr=document.querySelectorAll('.t-records');
Array.prototype.forEach.call(alr, function(el) {
el.classList.add("t-records_animated");
});
setTimeout(function () {
Array.prototype.forEach.call(alr, function(el) {
el.classList.add("t-records_visible");
});
sessionStorage.setItem("visited", "y");
}, 400);
} 
document.addEventListener('DOMContentLoaded', t_setvisRecs);
}
})();</script></head><body class="t-body" style="margin:0;"><!--allrecords--><div id="allrecords" data-tilda-export="yes" class="t-records" data-hook="blocks-collection-content-node" data-tilda-project-id="1465553" data-tilda-page-id="33098977" data-tilda-formskey="a0b3ebc6b7338134a33eca4420b48dce" data-tilda-lazy="yes"><!--header--><div id="t-header" class="t-records" data-hook="blocks-collection-content-node" data-tilda-project-id="1465553" data-tilda-page-id="6758374" data-tilda-formskey="a0b3ebc6b7338134a33eca4420b48dce" data-tilda-lazy="yes"><div id="rec154349466" class="r t-rec" style=" " data-record-type="215" ><a name="up" style="font-size:0;"></a></div><div id="rec227143068" class="r t-rec t-screenmin-980px" style=" " data-animationappear="off" data-record-type="257" data-screen-min="980px" ><!-- T228 --><div id="nav227143068marker"></div><div id="nav227143068" class="t228 t228__positionstatic " style="background-color: rgba(255,255,255,1); height:70px; " data-bgcolor-hex="#ffffff" data-bgcolor-rgba="rgba(255,255,255,1)" data-navmarker="nav227143068marker" data-appearoffset="" data-bgopacity-two="20" data-menushadow="" data-bgopacity="1" data-bgcolor-rgba-afterscroll="rgba(255,255,255,0.20)" data-menu-items-align="left" data-menu="yes"><div class="t228__maincontainer t228__c12collumns" style="height:70px;"><div class="t228__padding40px"></div><div class="t228__leftside"><div class="t228__leftcontainer"><a href="http://combasketteam.ru" class="t228__imgwrapper" style="color:#ffffff;"><img class="t228__imglogo t228__imglogomobile" 
src="images/tild6261-3031-4534-a533-346231616663__combasketnewlogo_gre.png" 
imgfield="img"
style="max-width: 50px; width: 50px; min-width: 50px; height: auto; display: block;"
alt="" role="presentation"></a></div></div><div class="t228__centerside t228__menualign_left"><nav class="t228__centercontainer" 
aria-label="Основные разделы на странице"><ul class="t228__list" 
role="menubar" aria-label="Основные разделы на странице"><li class="t228__list_item" 
role="none" 
style="padding:0 25px 0 0;"><a class="t-menu__link-item" 
href=""
role="menuitem" aria-haspopup="true" aria-expanded="false" tabindex="0" data-menu-submenu-hook="link_sub1_227143068" data-menu-item-number="1" 
style="color:#394045;font-size:14px;font-weight:600;font-family:'museo';letter-spacing:1px;">Каталог</a><div class="t-menusub" data-submenu-hook="link_sub1_227143068" data-submenu-margin="15px" data-add-submenu-arrow="on"><div class="t-menusub__menu"><div class="t-menusub__content"><ul class="t-menusub__list" role="menu" aria-label=""><li class="t-menusub__list-item t-name t-name_xs" role="none"><a class="t-menusub__link-item t-name t-name_xs" 
role="menuitem" 
href="/jersey-suits" 
style="" data-menu-item-number="1">Секции</a></li><li class="t-menusub__list-item t-name t-name_xs" role="none"><a class="t-menusub__link-item t-name t-name_xs" 
role="menuitem" 
href="/clothing" 
style="" data-menu-item-number="1">Стелажи</a></li><li class="t-menusub__list-item t-name t-name_xs" role="none"><a class="t-menusub__link-item t-name t-name_xs" 
role="menuitem" 
href="/backpacks" 
style="" data-menu-item-number="1">Акционный товар</a></li></ul></div></div></div></li><li class="t228__list_item" 
role="none" 
style="padding:0 25px;"><a class="t-menu__link-item" 
href="/examples"
role="menuitem" tabindex="0" data-menu-submenu-hook="" data-menu-item-number="2" 
style="color:#394045;font-size:14px;font-weight:600;font-family:'museo';letter-spacing:1px;">Больше информации</a></li><li class="t228__list_item" 
role="none" 
style="padding:0 25px;"><a class="t-menu__link-item" 
href="/order"
role="menuitem" tabindex="0" data-menu-submenu-hook="" data-menu-item-number="3" 
style="color:#394045;font-size:14px;font-weight:600;font-family:'museo';letter-spacing:1px;">Техническая поддержка</a></li><li class="t228__list_item" 
role="none" 
style="padding:0 0 0 25px;"><a class="t-menu__link-item" 
href="/contacts"
role="menuitem" tabindex="0" data-menu-submenu-hook="" data-menu-item-number="4" 
style="color:#394045;font-size:14px;font-weight:600;font-family:'museo';letter-spacing:1px;">Контакты</a></li></ul></nav></div><div class="t228__rightside"></div><div class="t228__padding40px"></div></div></div><style>@media screen and (max-width: 980px) {
#rec227143068 .t228__leftcontainer {
padding: 20px;
}
#rec227143068 .t228__imglogo {
padding: 20px 0;
}
#rec227143068 .t228 {
position: static;
}
}</style><script>window.addEventListener('resize', t_throttle(function () {
t_onFuncLoad('t_menu__setBGcolor', function () {
t_menu__setBGcolor('227143068', '.t228');
});
}));
t_onReady(function () {
t_onFuncLoad('t_menu__highlightActiveLinks', function () {
t_menu__highlightActiveLinks('.t228__list_item a');
});
t_onFuncLoad('t228__init', function () {
t228__init('227143068');
});
t_onFuncLoad('t_menu__setBGcolor', function () {
t_menu__setBGcolor('227143068', '.t228');
});
});</script><!--[if IE 8]><style>#rec227143068 .t228 {
filter: progid:DXImageTransform.Microsoft.gradient(startColorStr='#D9ffffff', endColorstr='#D9ffffff');
}</style><![endif]--><style>#rec227143068 .t-menu__link-item{
-webkit-transition: color 0.3s ease-in-out, opacity 0.3s ease-in-out;
transition: color 0.3s ease-in-out, opacity 0.3s ease-in-out; 
outline: none;
}
/* #rec227143068 .t-menu__link-item:not(:focus-visible){
outline: none;
} */
#rec227143068 .t-menu__link-item.t-active:not(.t978__menu-link){
color:#eb974e !important; }
#rec227143068 .t-menu__link-item:not(.t-active):not(.tooltipstered):hover{
color: #eb974e !important; }
@supports (overflow:-webkit-marquee) and (justify-content:inherit)
{
#rec227143068 .t-menu__link-item,
#rec227143068 .t-menu__link-item.t-active {
opacity: 1 !important;
}
}</style><script>t_onReady(function () {
setTimeout(function(){
t_onFuncLoad('t_menusub_init', function() {
t_menusub_init('227143068');
});
}, 500);
});</script><style>@media screen and (max-width: 980px) {
#rec227143068 .t-menusub__menu .t-menusub__link-item {
color:#394045 !important;
}
#rec227143068 .t-menusub__menu .t-menusub__link-item.t-active {
color:#394045 !important;
}
}
@media screen and (min-width: 981px) { #rec227143068 .t-menusub__menu {
max-width:120px; }
}</style></div><div id="rec216819938" class="r t-rec t-rec_pb_0 t-screenmax-980px" style="padding-bottom:0px; " data-animationappear="off" data-record-type="257" data-screen-max="980px" ><!-- T228 --><div id="nav216819938marker"></div><div class="tmenu-mobile" ><div class="tmenu-mobile__container"><div class="tmenu-mobile__text t-name t-name_md" field="menu_mob_title">NePROD</div><div class="t-menuburger t-menuburger_first "><span style="background-color:#363b3f;"></span><span style="background-color:#363b3f;"></span><span style="background-color:#363b3f;"></span><span style="background-color:#363b3f;"></span></div><script>function t_menuburger_init(recid) {
var rec = document.querySelector('#rec' + recid);
if (!rec) return;
var burger = rec.querySelector('.t-menuburger');
if (!burger) return;
var isSecondStyle = burger.classList.contains('t-menuburger_second');
if (isSecondStyle && !window.isMobile && !('ontouchend' in document)) {
burger.addEventListener('mouseenter', function() {
if (burger.classList.contains('t-menuburger-opened')) return;
burger.classList.remove('t-menuburger-unhovered');
burger.classList.add('t-menuburger-hovered');
});
burger.addEventListener('mouseleave', function() {
if (burger.classList.contains('t-menuburger-opened')) return;
burger.classList.remove('t-menuburger-hovered');
burger.classList.add('t-menuburger-unhovered');
setTimeout(function() {
burger.classList.remove('t-menuburger-unhovered');
}, 300);
});
}
if (!burger.closest('.tmenu-mobile') &&
!burger.closest('.t450__burger_container') &&
!burger.closest('.t204__burger')) {
burger.addEventListener('click', function() {
burger.classList.toggle('t-menuburger-opened');
burger.classList.remove('t-menuburger-unhovered');
});
}
var menu = rec.querySelector('[data-menu="yes"]');
if (!menu) return;
var menuLinks = menu.querySelectorAll('.t-menu__link-item');
var submenuClassList = ['t978__menu-link_hook', 't978__tm-link', 't966__tm-link', 't794__tm-link', 't-menusub__target-link'];
Array.prototype.forEach.call(menuLinks, function (link) {
link.addEventListener('click', function () {
var isSubmenuHook = submenuClassList.some(function (submenuClass) {
return link.classList.contains(submenuClass);
});
if (isSubmenuHook) return;
burger.classList.remove('t-menuburger-opened');
});
});
}
t_onReady(function() {
t_onFuncLoad('t_menuburger_init', function(){t_menuburger_init('216819938');});
});</script><style>.t-menuburger {
position: relative;
flex-shrink: 0;
width: 28px;
height: 20px;
-webkit-transform: rotate(0deg);
transform: rotate(0deg);
transition: .5s ease-in-out;
cursor: pointer;
z-index: 999;
}
/*---menu burger lines---*/
.t-menuburger span {
display: block;
position: absolute;
width: 100%;
opacity: 1;
left: 0;
-webkit-transform: rotate(0deg);
transform: rotate(0deg);
transition: .25s ease-in-out;
height: 3px;
background-color: #000;
}
.t-menuburger span:nth-child(1) {
top: 0px;
}
.t-menuburger span:nth-child(2),
.t-menuburger span:nth-child(3) {
top: 8px;
}
.t-menuburger span:nth-child(4) {
top: 16px;
}
/*menu burger big*/
.t-menuburger__big {
width: 42px;
height: 32px;
}
.t-menuburger__big span {
height: 5px;
}
.t-menuburger__big span:nth-child(2),
.t-menuburger__big span:nth-child(3) {
top: 13px;
}
.t-menuburger__big span:nth-child(4) {
top: 26px;
}
/*menu burger small*/
.t-menuburger__small {
width: 22px;
height: 14px;
}
.t-menuburger__small span {
height: 2px;
}
.t-menuburger__small span:nth-child(2),
.t-menuburger__small span:nth-child(3) {
top: 6px;
}
.t-menuburger__small span:nth-child(4) {
top: 12px;
}
/*menu burger opened*/
.t-menuburger-opened span:nth-child(1) {
top: 8px;
width: 0%;
left: 50%;
}
.t-menuburger-opened span:nth-child(2) {
-webkit-transform: rotate(45deg);
transform: rotate(45deg);
}
.t-menuburger-opened span:nth-child(3) {
-webkit-transform: rotate(-45deg);
transform: rotate(-45deg);
}
.t-menuburger-opened span:nth-child(4) {
top: 8px;
width: 0%;
left: 50%;
}
.t-menuburger-opened.t-menuburger__big span:nth-child(1) {
top: 6px;
}
.t-menuburger-opened.t-menuburger__big span:nth-child(4) {
top: 18px;
}
.t-menuburger-opened.t-menuburger__small span:nth-child(1),
.t-menuburger-opened.t-menuburger__small span:nth-child(4) {
top: 6px;
}
/*---menu burger first style---*/
@media (hover), (min-width:0\0) {
.t-menuburger_first:hover span:nth-child(1) {
transform: translateY(1px);
}
.t-menuburger_first:hover span:nth-child(4) {
transform: translateY(-1px);
}
.t-menuburger_first.t-menuburger__big:hover span:nth-child(1) {
transform: translateY(3px);
}
.t-menuburger_first.t-menuburger__big:hover span:nth-child(4) {
transform: translateY(-3px);
}
}
/*---menu burger second style---*/
.t-menuburger_second span:nth-child(2),
.t-menuburger_second span:nth-child(3) {
width: 80%;
left: 20%;
right: 0;
}
@media (hover), (min-width:0\0) {
.t-menuburger_second.t-menuburger-hovered span:nth-child(2),
.t-menuburger_second.t-menuburger-hovered span:nth-child(3) {
animation: t-menuburger-anim 0.3s ease-out normal forwards;
}
.t-menuburger_second.t-menuburger-unhovered span:nth-child(2),
.t-menuburger_second.t-menuburger-unhovered span:nth-child(3) {
animation: t-menuburger-anim2 0.3s ease-out normal forwards;
}
}
.t-menuburger_second.t-menuburger-opened span:nth-child(2),
.t-menuburger_second.t-menuburger-opened span:nth-child(3){
left: 0;
right: 0;
width: 100%!important;
}
/*---menu burger third style---*/
.t-menuburger_third span:nth-child(4) {
width: 70%;
left: unset;
right: 0;
}
@media (hover), (min-width:0\0) {
.t-menuburger_third:not(.t-menuburger-opened):hover span:nth-child(4) {
width: 100%;
}
}
.t-menuburger_third.t-menuburger-opened span:nth-child(4) {
width: 0!important;
right: 50%;
}
/*---menu burger fourth style---*/
.t-menuburger_fourth {
height: 12px;
}
.t-menuburger_fourth.t-menuburger__small {
height: 8px;
}
.t-menuburger_fourth.t-menuburger__big {
height: 18px;
}
.t-menuburger_fourth span:nth-child(2),
.t-menuburger_fourth span:nth-child(3) {
top: 4px;
opacity: 0;
}
.t-menuburger_fourth span:nth-child(4) {
top: 8px;
}
.t-menuburger_fourth.t-menuburger__small span:nth-child(2),
.t-menuburger_fourth.t-menuburger__small span:nth-child(3) {
top: 3px;
}
.t-menuburger_fourth.t-menuburger__small span:nth-child(4) {
top: 6px;
}
.t-menuburger_fourth.t-menuburger__small span:nth-child(2),
.t-menuburger_fourth.t-menuburger__small span:nth-child(3) {
top: 3px;
}
.t-menuburger_fourth.t-menuburger__small span:nth-child(4) {
top: 6px;
}
.t-menuburger_fourth.t-menuburger__big span:nth-child(2),
.t-menuburger_fourth.t-menuburger__big span:nth-child(3) {
top: 6px;
}
.t-menuburger_fourth.t-menuburger__big span:nth-child(4) {
top: 12px;
}
@media (hover), (min-width:0\0) {
.t-menuburger_fourth:not(.t-menuburger-opened):hover span:nth-child(1) {
transform: translateY(1px);
}
.t-menuburger_fourth:not(.t-menuburger-opened):hover span:nth-child(4) {
transform: translateY(-1px);
}
.t-menuburger_fourth.t-menuburger__big:not(.t-menuburger-opened):hover span:nth-child(1) {
transform: translateY(3px);
}
.t-menuburger_fourth.t-menuburger__big:not(.t-menuburger-opened):hover span:nth-child(4) {
transform: translateY(-3px);
}
}
.t-menuburger_fourth.t-menuburger-opened span:nth-child(1),
.t-menuburger_fourth.t-menuburger-opened span:nth-child(4) {
top: 4px;
}
.t-menuburger_fourth.t-menuburger-opened span:nth-child(2),
.t-menuburger_fourth.t-menuburger-opened span:nth-child(3) {
opacity: 1;
}
/*---menu burger animations---*/
@keyframes t-menuburger-anim {
0% {
width: 80%;
left: 20%;
right: 0;
}
50% {
width: 100%;
left: 0;
right: 0;
}
100% {
width: 80%;
left: 0;
right: 20%;
}
}
@keyframes t-menuburger-anim2 {
0% {
width: 80%;
left: 0;
}
50% {
width: 100%;
right: 0;
left: 0;
}
100% {
width: 80%;
left: 20%;
right: 0;
}
}</style> </div></div><style>.tmenu-mobile {
background-color: #111;
display: none;
width: 100%;
top: 0;
z-index: 990;
}
.tmenu-mobile_positionfixed {
position: fixed;
}
.tmenu-mobile__text {
color: #fff;
}
.tmenu-mobile__container {
min-height: 64px;
padding: 20px;
position: relative;
box-sizing: border-box;
display: -webkit-flex;
display: -ms-flexbox;
display: flex;
-webkit-align-items: center;
-ms-flex-align: center;
align-items: center;
-webkit-justify-content: space-between;
-ms-flex-pack: justify;
justify-content: space-between;
}
.tmenu-mobile__list {
display: block;
}
.tmenu-mobile__burgerlogo {
display: inline-block;
font-size: 24px;
font-weight: 400;
white-space: nowrap;
vertical-align: middle;
}
.tmenu-mobile__imglogo {
height: auto;
display: block;
max-width: 300px!important;
box-sizing: border-box;
padding: 0;
margin: 0 auto;
}
@media screen and (max-width: 980px) {
.tmenu-mobile__menucontent_hidden {
display: none;
height: 100%;
}
.tmenu-mobile {
display: block;
}
}
@media screen and (max-width: 980px) {
#rec216819938 .t-menuburger {
-webkit-order: 1;
-ms-flex-order: 1;
order: 1;
}
}</style><style>@media screen and (max-width: 980px) {
#rec216819938 .t-menusub__menu .t-menusub__link-item {
color:#363b3f !important;
}
#rec216819938 .t-menusub__menu .t-menusub__link-item.t-active {
color:#363b3f !important;
}
}</style></div><div id="rec192105913" class="r t-rec" style=" " data-animationappear="off" data-record-type="360" ><!-- T360 --><style>.t-records {
opacity: 0;
}
.t-records_animated {
-webkit-transition: opacity ease-in-out .5s;
-moz-transition: opacity ease-in-out .5s;
-o-transition: opacity ease-in-out .5s;
transition: opacity ease-in-out .5s;
}
.t-records.t-records_visible,
.t-records .t-records {
opacity: 1;
}</style><script>t_onReady(function () {
var allRecords = document.querySelector('.t-records');
window.addEventListener('pageshow', function (event) {
if (event.persisted) {
allRecords.classList.add('t-records_visible');
}
});
var rec = document.querySelector('#rec192105913');
if (!rec) return;
rec.setAttribute('data-animationappear', 'off');
rec.style.opacity = '1';
allRecords.classList.add('t-records_animated');
setTimeout(function () {
allRecords.classList.add('t-records_visible');
}, 200);
});</script><script>t_onReady(function () {
var selects = 'button:not(.t-submit):not(.t835__btn_next):not(.t835__btn_prev):not(.t835__btn_result):not(.t862__btn_next):not(.t862__btn_prev):not(.t862__btn_result):not(.t854__news-btn):not(.t862__btn_next),' +
'a:not([href*="#"]):not(.carousel-control):not(.t-carousel__control):not(.t807__btn_reply):not([href^="#price"]):not([href^="javascript"]):not([href^="mailto"]):not([href^="tel"]):not([href^="link_sub"]):not(.js-feed-btn-show-more):not(.t367__opener):not([href^="https://www.dropbox.com/"])';
var elements = document.querySelectorAll(selects);
Array.prototype.forEach.call(elements, function (element) {
if (element.getAttribute('data-menu-submenu-hook')) return;
element.addEventListener('click', function (event) {
var goTo = this.getAttribute('href');
if (goTo !== null) {
var ctrl = event.ctrlKey;
var cmd = event.metaKey && navigator.platform.indexOf('Mac') !== -1;
if (!ctrl && !cmd) {
var target = this.getAttribute('target');
if (target !== '_blank') {
event.preventDefault();
var allRecords = document.querySelector('.t-records');
allRecords.classList.remove('t-records_visible');
setTimeout(function () {
window.location = goTo;
}, 500);
}
}
}
});
});
});</script><style>.t360__bar {
background-color: #eb974e;
}</style><script>t_onReady(function () {
var isSafari = /Safari/.test(navigator.userAgent) && /Apple Computer/.test(navigator.vendor);
if (!isSafari) {
document.body.insertAdjacentHTML('beforeend', '<div class="t360__progress"><div class="t360__bar"></div></div>');
setTimeout(function () {
var bar = document.querySelector('.t360__bar');
if (bar) bar.classList.add('t360__barprogress');
}, 10);
}
});
window.addEventListener('load', function () {
var bar = document.querySelector('.t360__bar');
if (!bar) return;
bar.classList.remove('t360__barprogress');
bar.classList.add('t360__barprogressfinished');
setTimeout(function () {
bar.classList.add('t360__barprogresshidden');
}, 20);
setTimeout(function () {
var progress = document.querySelector('.t360__progress');
if (progress) progress.style.display = 'none';
}, 500);
});</script></div></div><!--/header--><div id="rec535030112" class="r t-rec" style="background-color:#fa0026; " data-animationappear="off" data-record-type="454" data-bg-color="#fa0026"><!-- T454 --><div id="nav535030112marker"></div><div id="nav535030112" class="t454 t454__positionstatic " style="background-color: rgba(207,0,0,1); height:100px; " data-bgcolor-hex="#cf0000" data-bgcolor-rgba="rgba(207,0,0,1)" data-navmarker="nav535030112marker" data-appearoffset="" data-bgopacity-two="" data-menushadow="" data-bgopacity="1" data-menu="yes"><div class="t454__maincontainer t454__c12collumns" style="height:100px;"><div class="t454__logowrapper"><div class="t454__logowrapper2"><div ><a href="https://google.com" style="color:#ffffff;"><div class="t454__logo t-title" field="title" style="color:#ffffff;">NePROD</div></a></div></div></div><div class="t454__leftwrapper" style="padding-left:20px; padding-right:160px; text-align: left;"><nav class="t454__leftmenuwrapper" 
aria-label="Основные разделы на странице"><ul class="t454__list" 
role="menubar" aria-label="Основные разделы на странице"><li class="t454__list_item" 
role="none" 
style="padding:0 15px 0 0;"><a class="t-menu__link-item" 
href=""
role="menuitem" tabindex="0" data-menu-submenu-hook="" data-menu-item-number="1" 
style="color:#ffffff;font-weight:600;" >О компании</a></li><li class="t454__list_item" 
role="none" 
style="padding:0 15px;"><a class="t-menu__link-item" 
href=""
role="menuitem" tabindex="0" data-menu-submenu-hook="" data-menu-item-number="2" 
style="color:#ffffff;font-weight:600;" >Как купить</a></li><li class="t454__list_item" 
role="none" 
style="padding:0 0 0 15px;"><a class="t-menu__link-item" 
href=""
role="menuitem" tabindex="0" data-menu-submenu-hook="" data-menu-item-number="3" 
style="color:#ffffff;font-weight:600;" >Проекты</a></li></ul></nav></div><div class="t454__rightwrapper" style="padding-right:20px; padding-left:160px; text-align: right;"><nav class="t454__rightmenuwrapper"><ul class="t454__list"><li class="t454__list_item" style="padding:0 15px 0 0;"><a class="t-menu__link-item" href="" data-menu-submenu-hook="" style="color:#ffffff;font-weight:600;" data-menu-item-number="4">Новости</a></li><li class="t454__list_item" style="padding:0 15px;"><a class="t-menu__link-item" href="" data-menu-submenu-hook="" style="color:#ffffff;font-weight:600;" data-menu-item-number="5">Партнеры</a></li><li class="t454__list_item" style="padding:0 15px;"><a class="t-menu__link-item" href="" data-menu-submenu-hook="" style="color:#ffffff;font-weight:600;" data-menu-item-number="6">Отзывы</a></li><li class="t454__list_item" style="padding:0 0 0 15px;"><a class="t-menu__link-item" href="" data-menu-submenu-hook="" style="color:#ffffff;font-weight:600;" data-menu-item-number="7">Контакты</a></li></ul></nav></div></div></div><style>@media screen and (max-width: 980px) {
#rec535030112 .t454__leftcontainer{
padding: 20px;
}
}
@media screen and (max-width: 980px) {
#rec535030112 .t454__imglogo{
padding: 20px 0;
}
}</style><script>t_onReady(function() {
t_onFuncLoad('t_menu__highlightActiveLinks', function () {
t_menu__highlightActiveLinks('.t454__list_item a');
});
});
t_onFuncLoad('t_menu__setBGcolor', function () {
window.addEventListener('resize', t_throttle(function () {
t_menu__setBGcolor('535030112', '.t454');
}));
});
t_onReady(function () {
t_onFuncLoad('t_menu__setBGcolor', function () {
t_menu__setBGcolor('535030112', '.t454');
});
});</script><style>#rec535030112 .t-menu__link-item{
outline: none;
}
/* #rec535030112 .t-menu__link-item:not(:focus-visible){
outline: none;
} */
@supports (overflow:-webkit-marquee) and (justify-content:inherit)
{
#rec535030112 .t-menu__link-item,
#rec535030112 .t-menu__link-item.t-active {
opacity: 1 !important;
}
}</style><!--[if IE 8]><style>#rec535030112 .t454 {
filter: progid:DXImageTransform.Microsoft.gradient(startColorStr='#D9cf0000', endColorstr='#D9cf0000');
}</style><![endif]--></div><div id="rec535030478" class="r t-rec t-rec_pt_120 t-rec_pb_120" style="padding-top:120px;padding-bottom:120px; " data-animationappear="off" data-record-type="838" ><!-- t838 --><!-- @classes: t-text --><div class="t838"><div class="t-container"><div class="t-col t-col_8 t-prefix_2"><div class="t838__wrapper t-site-search-input"><div class="t838__blockinput"><input type="text" class="t838__input t-input " placeholder="" data-search-target="all" style="color:#000000; border:1px solid #000000; border-radius: 3px; -moz-border-radius: 3px; -webkit-border-radius: 3px;"><svg role="img" class="t838__search-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 88 88"><path fill="#b6b6b6" d="M85 31.1c-.5-8.7-4.4-16.6-10.9-22.3C67.6 3 59.3 0 50.6.6c-8.7.5-16.7 4.4-22.5 11-11.2 12.7-10.7 31.7.6 43.9l-5.3 6.1-2.5-2.2-17.8 20 9 8.1 17.8-20.2-2.1-1.8 5.3-6.1c5.8 4.2 12.6 6.3 19.3 6.3 9 0 18-3.7 24.4-10.9 5.9-6.6 8.8-15 8.2-23.7zM72.4 50.8c-9.7 10.9-26.5 11.9-37.6 2.3-10.9-9.8-11.9-26.6-2.3-37.6 4.7-5.4 11.3-8.5 18.4-8.9h1.6c6.5 0 12.7 2.4 17.6 6.8 5.3 4.7 8.5 11.1 8.9 18.2.5 7-1.9 13.8-6.6 19.2z"/></svg></div><div class="t838__blockbutton"><button class="t-submit" style="color:#ffffff;background-color:#000000;border-radius:3px; -moz-border-radius:3px; -webkit-border-radius:3px;">Поиск</button></div></div></div></div></div><script>t_onReady(function () {
var tildaSearch = 'https://static.tilda' + 'cdn.com/js/tilda-search-';
if (!document.querySelector('script[src^="https://search.tildacdn.com/static/tilda-search-"]') && !document.querySelector('script[src^="' + tildaSearch + '"]')) {
var script = document.createElement('script');
script.src = tildaSearch + '1.2.min.js';
script.type = 'text/javascript';
document.body.appendChild(script);
}
});</script><style>#rec535030478 input::-webkit-input-placeholder {color:#000000; opacity: 0.5;}
#rec535030478 input::-moz-placeholder {color:#000000; opacity: 0.5;}
#rec535030478 input:-moz-placeholder {color:#000000; opacity: 0.5;}
#rec535030478 input:-ms-input-placeholder {color:#000000; opacity: 0.5;}</style></div><div id="rec535030494" class="r t-rec" style=" " data-animationappear="off" data-record-type="396" ><!-- T396 --><style>#rec535030494 .t396__artboard {height: 70px; background-color: #ffffff; }#rec535030494 .t396__filter {height: 70px; }#rec535030494 .t396__carrier{height: 70px; background-position: center center; background-attachment: scroll;background-size: cover;background-repeat: no-repeat;}@media screen and (max-width: 1199px) {#rec535030494 .t396__artboard {}#rec535030494 .t396__filter {}#rec535030494 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 959px) {#rec535030494 .t396__artboard {height: 70px;}#rec535030494 .t396__filter {height: 70px;}#rec535030494 .t396__carrier {height: 70px;background-attachment: scroll;}}@media screen and (max-width: 639px) {#rec535030494 .t396__artboard {}#rec535030494 .t396__filter {}#rec535030494 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 479px) {#rec535030494 .t396__artboard {}#rec535030494 .t396__filter {}#rec535030494 .t396__carrier {background-attachment: scroll;}} #rec535030494 .tn-elem[data-elem-id="1673219579843"] { z-index: 1; top: 13px;left: calc(50% - 600px + 18px);width: 1164px;height:48px;}#rec535030494 .tn-elem[data-elem-id="1673219579843"] .tn-atom { background-color: #cf0000; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535030494 .tn-elem[data-elem-id="1673219612223"] { color: #ffffff; z-index: 2; top: 20px;left: calc(50% - 600px + 50px);width: 77px;}#rec535030494 .tn-elem[data-elem-id="1673219612223"] .tn-atom { color: #ffffff; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535030494 .tn-elem[data-elem-id="1673219639787"] { color: #ffffff; z-index: 3; top: 20px;left: calc(50% - 600px + 140px);width: 275px;}#rec535030494 .tn-elem[data-elem-id="1673219639787"] .tn-atom { color: #ffffff; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535030494 .tn-elem[data-elem-id="1673219681930"] { color: #ffffff; z-index: 4; top: 20px;left: calc(50% - 600px + 440px);width: 275px;}#rec535030494 .tn-elem[data-elem-id="1673219681930"] .tn-atom { color: #ffffff; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535030494 .tn-elem[data-elem-id="1673219745504"] { color: #ffffff; z-index: 5; top: 20px;left: calc(50% - 600px + 740px);width: 245px;}#rec535030494 .tn-elem[data-elem-id="1673219745504"] .tn-atom { color: #ffffff; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535030494 .tn-elem[data-elem-id="1673219796826"] { color: #ffffff; z-index: 6; top: 20px;left: calc(50% - 600px + 1000px);width: 80px;}#rec535030494 .tn-elem[data-elem-id="1673219796826"] .tn-atom { color: #ffffff; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {}</style><div class='t396'><div class="t396__artboard" data-artboard-recid="535030494" data-artboard-screens="320,480,640,960,1200" data-artboard-height="70" data-artboard-valign="center" data-artboard-upscale="grid" data-artboard-height-res-640="70" 
><div class="t396__carrier" data-artboard-recid="535030494"></div><div class="t396__filter" data-artboard-recid="535030494"></div><div class='t396__elem tn-elem tn-elem__5350304941673219579843' data-elem-id='1673219579843' data-elem-type='shape' data-field-top-value="13" data-field-left-value="18" data-field-height-value="48" data-field-width-value="1164" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="px" data-field-widthunits-value="px"
><div class='tn-atom' ></div></div> <div class='t396__elem tn-elem tn-elem__5350304941673219612223' data-elem-id='1673219612223' data-elem-type='text' data-field-top-value="20" data-field-left-value="50" data-field-width-value="77" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px"
><div class='tn-atom'field='tn_text_1673219612223'>Акции |</div> </div> <div class='t396__elem tn-elem tn-elem__5350304941673219639787' data-elem-id='1673219639787' data-elem-type='text' data-field-top-value="20" data-field-left-value="140" data-field-width-value="275" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px"
><div class='tn-atom'field='tn_text_1673219639787'>Холодильное оборудование</div> </div> <div class='t396__elem tn-elem tn-elem__5350304941673219681930' data-elem-id='1673219681930' data-elem-type='text' data-field-top-value="20" data-field-left-value="440" data-field-width-value="275" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px"
><div class='tn-atom'field='tn_text_1673219681930'>Стеллажное оборудование</div> </div> <div class='t396__elem tn-elem tn-elem__5350304941673219745504' data-elem-id='1673219745504' data-elem-type='text' data-field-top-value="20" data-field-left-value="740" data-field-width-value="245" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px"
><div class='tn-atom'field='tn_text_1673219745504'>Кухонное оборудование</div> </div> <div class='t396__elem tn-elem tn-elem__5350304941673219796826' data-elem-id='1673219796826' data-elem-type='text' data-field-top-value="20" data-field-left-value="1000" data-field-width-value="80" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px"
><div class='tn-atom'field='tn_text_1673219796826'>Другое</div> </div> </div> </div> <script>t_onReady(function () {
t_onFuncLoad('t396_init', function () {
t396_init('535030494');
});
});</script><!-- /T396 --></div><div id="rec535033569" class="r t-rec" style=" " data-animationappear="off" data-record-type="396" ><!-- T396 --><style>#rec535033569 .t396__artboard {height: 100px; background-color: #ffffff; }#rec535033569 .t396__filter {height: 100px; }#rec535033569 .t396__carrier{height: 100px; background-position: center center; background-attachment: scroll;background-size: cover;background-repeat: no-repeat;}@media screen and (max-width: 1199px) {#rec535033569 .t396__artboard {}#rec535033569 .t396__filter {}#rec535033569 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 959px) {#rec535033569 .t396__artboard {}#rec535033569 .t396__filter {}#rec535033569 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 639px) {#rec535033569 .t396__artboard {}#rec535033569 .t396__filter {}#rec535033569 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 479px) {#rec535033569 .t396__artboard {}#rec535033569 .t396__filter {}#rec535033569 .t396__carrier {background-attachment: scroll;}} #rec535033569 .tn-elem[data-elem-id="1673221327320"] { color: #000000; z-index: 1; top: 20px;left: calc(50% - 600px + 20px);width: 1280px;}#rec535033569 .tn-elem[data-elem-id="1673221327320"] .tn-atom { color: #000000; font-size: 40px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {}</style><div class='t396'><div class="t396__artboard" data-artboard-recid="535033569" data-artboard-screens="320,480,640,960,1200" data-artboard-height="100" data-artboard-valign="center" data-artboard-upscale="grid" 
><div class="t396__carrier" data-artboard-recid="535033569"></div><div class="t396__filter" data-artboard-recid="535033569"></div><div class='t396__elem tn-elem tn-elem__5350335691673221327320' data-elem-id='1673221327320' data-elem-type='text' data-field-top-value="20" data-field-left-value="20" data-field-width-value="1280" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px"
><div class='tn-atom'field='tn_text_1673221327320'><strong>Магазины по продаже непродовольственных товаров</strong></div> </div> </div> </div> <script>t_onReady(function () {
t_onFuncLoad('t396_init', function () {
t396_init('535033569');
});
});</script><!-- /T396 --></div><div id="rec535030495" class="r t-rec" style=" " data-animationappear="off" data-record-type="396" ><!-- T396 --><style>#rec535030495 .t396__artboard {height: 330px; background-color: #ffffff; }#rec535030495 .t396__filter {height: 330px; }#rec535030495 .t396__carrier{height: 330px; background-position: center center; background-attachment: scroll;background-size: cover;background-repeat: no-repeat;}@media screen and (max-width: 1199px) {#rec535030495 .t396__artboard {}#rec535030495 .t396__filter {}#rec535030495 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 959px) {#rec535030495 .t396__artboard {height: 330px;}#rec535030495 .t396__filter {height: 330px;}#rec535030495 .t396__carrier {height: 330px;background-attachment: scroll;}}@media screen and (max-width: 639px) {#rec535030495 .t396__artboard {}#rec535030495 .t396__filter {}#rec535030495 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 479px) {#rec535030495 .t396__artboard {}#rec535030495 .t396__filter {}#rec535030495 .t396__carrier {background-attachment: scroll;}} #rec535030495 .tn-elem[data-elem-id="1673219898899"] { z-index: 1; top: 16px;left: calc(50% - 600px + 0px);width: 1143px;height:322px;}#rec535030495 .tn-elem[data-elem-id="1673219898899"] .tn-atom { background-color: #cf0000; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535030495 .tn-elem[data-elem-id="1673219927431"] { color: #ffffff; z-index: 2; top: 30px;left: calc(50% - 600px + 40px);width: 222px;}#rec535030495 .tn-elem[data-elem-id="1673219927431"] .tn-atom { color: #ffffff; font-size: 35px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535030495 .tn-elem[data-elem-id="1673219985473"] { color: #ffffff; z-index: 3; top: 93px;left: calc(50% - 600px + 40px);width: 351px;}#rec535030495 .tn-elem[data-elem-id="1673219985473"] .tn-atom { color: #ffffff; font-size: 35px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535030495 .tn-elem[data-elem-id="1673220049303"] { color: #ffffff; z-index: 4; top: 155px;left: calc(50% - 600px + 40px);width: 210px;}#rec535030495 .tn-elem[data-elem-id="1673220049303"] .tn-atom { color: #ffffff; font-size: 35px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535030495 .tn-elem[data-elem-id="1673220105746"] { color: #ffffff; z-index: 5; top: 215px;left: calc(50% - 600px + 40px);width: 465px;}#rec535030495 .tn-elem[data-elem-id="1673220105746"] .tn-atom { color: #ffffff; font-size: 35px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535030495 .tn-elem[data-elem-id="1673220276877"] { z-index: 6; top: 40px;left: calc(50% - 600px + 262px);width: 35px;}#rec535030495 .tn-elem[data-elem-id="1673220276877"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535030495 .tn-elem[data-elem-id="1673220310648"] { z-index: 7; top: 100px;left: calc(50% - 600px + 375px);width: 35px;}#rec535030495 .tn-elem[data-elem-id="1673220310648"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535030495 .tn-elem[data-elem-id="1673220344803"] { z-index: 8; top: 165px;left: calc(50% - 600px + 210px);width: 35px;}#rec535030495 .tn-elem[data-elem-id="1673220344803"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535030495 .tn-elem[data-elem-id="1673220387479"] { z-index: 9; top: 225px;left: calc(50% - 600px + 500px);width: 35px;}#rec535030495 .tn-elem[data-elem-id="1673220387479"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535030495 .tn-elem[data-elem-id="1673220645079"] { z-index: 10; top: 160px;left: calc(50% - 600px + 774px);width: 158px;}#rec535030495 .tn-elem[data-elem-id="1673220645079"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}#rec535030495 .tn-elem[data-elem-id="1673220645079"] .tn-atom {-webkit-transform:rotate(45deg);-moz-transform:rotate(45deg);transform:rotate(45deg);}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535030495 .tn-elem[data-elem-id="1673220665756"] { z-index: 11; top: 16px;left: calc(50% - 600px + 932px);width: 200px;}#rec535030495 .tn-elem[data-elem-id="1673220665756"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}#rec535030495 .tn-elem[data-elem-id="1673220665756"] .tn-atom {-webkit-transform:rotate(45deg);-moz-transform:rotate(45deg);transform:rotate(45deg);}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535030495 .tn-elem[data-elem-id="1673220683538"] { z-index: 12; top: 25px;left: calc(50% - 600px + 650px);width: 160px;}#rec535030495 .tn-elem[data-elem-id="1673220683538"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}#rec535030495 .tn-elem[data-elem-id="1673220683538"] .tn-atom {-webkit-transform:rotate(45deg);-moz-transform:rotate(45deg);transform:rotate(45deg);}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {}</style><div class='t396'><div class="t396__artboard" data-artboard-recid="535030495" data-artboard-screens="320,480,640,960,1200" data-artboard-height="330" data-artboard-valign="center" data-artboard-upscale="grid" data-artboard-height-res-640="330" 
><div class="t396__carrier" data-artboard-recid="535030495"></div><div class="t396__filter" data-artboard-recid="535030495"></div><div class='t396__elem tn-elem tn-elem__5350304951673219898899' data-elem-id='1673219898899' data-elem-type='shape' data-field-top-value="16" data-field-left-value="0" data-field-height-value="322" data-field-width-value="1143" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="px" data-field-widthunits-value="px"
><div class='tn-atom' ></div></div> <div class='t396__elem tn-elem tn-elem__5350304951673219927431' data-elem-id='1673219927431' data-elem-type='text' data-field-top-value="30" data-field-left-value="40" data-field-width-value="222" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px"
><div class='tn-atom'field='tn_text_1673219927431'>Лучшая цена</div> </div> <div class='t396__elem tn-elem tn-elem__5350304951673219985473' data-elem-id='1673219985473' data-elem-type='text' data-field-top-value="93" data-field-left-value="40" data-field-width-value="351" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px"
><div class='tn-atom'field='tn_text_1673219985473'>Гарантия 24 месяца</div> </div> <div class='t396__elem tn-elem tn-elem__5350304951673220049303' data-elem-id='1673220049303' data-elem-type='text' data-field-top-value="155" data-field-left-value="40" data-field-width-value="210" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px"
><div class='tn-atom'field='tn_text_1673220049303'>Год опыта</div> </div> <div class='t396__elem tn-elem tn-elem__5350304951673220105746' data-elem-id='1673220105746' data-elem-type='text' data-field-top-value="215" data-field-left-value="40" data-field-width-value="465" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px"
><div class='tn-atom'field='tn_text_1673220105746'>Поможем подобрать товар</div> </div> <div class='t396__elem tn-elem tn-elem__5350304951673220276877' data-elem-id='1673220276877' data-elem-type='image' data-field-top-value="40" data-field-left-value="262" data-field-width-value="35" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-filewidth-value="512" data-field-fileheight-value="511" 
><div class='tn-atom' ><img class='tn-atom__img t-img' data-original='images/tild6163-3430-4638-b364-326638343262__noroot.png' imgfield='tn_img_1673220276877'></div></div> <div class='t396__elem tn-elem tn-elem__5350304951673220310648' data-elem-id='1673220310648' data-elem-type='image' data-field-top-value="100" data-field-left-value="375" data-field-width-value="35" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-filewidth-value="512" data-field-fileheight-value="511" 
><div class='tn-atom' ><img class='tn-atom__img t-img' data-original='images/tild3863-3466-4737-b237-303562633537__noroot.png' imgfield='tn_img_1673220310648'></div></div> <div class='t396__elem tn-elem tn-elem__5350304951673220344803' data-elem-id='1673220344803' data-elem-type='image' data-field-top-value="165" data-field-left-value="210" data-field-width-value="35" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-filewidth-value="512" data-field-fileheight-value="511" 
><div class='tn-atom' ><img class='tn-atom__img t-img' data-original='images/tild6434-6130-4964-b366-633735616661__noroot.png' imgfield='tn_img_1673220344803'></div></div> <div class='t396__elem tn-elem tn-elem__5350304951673220387479' data-elem-id='1673220387479' data-elem-type='image' data-field-top-value="225" data-field-left-value="500" data-field-width-value="35" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-filewidth-value="512" data-field-fileheight-value="511" 
><div class='tn-atom' ><img class='tn-atom__img t-img' data-original='images/tild6463-6338-4265-b266-323933363935__noroot.png' imgfield='tn_img_1673220387479'></div></div> <div class='t396__elem tn-elem tn-elem__5350304951673220645079' data-elem-id='1673220645079' data-elem-type='image' data-field-top-value="160" data-field-left-value="774" data-field-width-value="158" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-filewidth-value="512" data-field-fileheight-value="511" 
><div class='tn-atom' ><img class='tn-atom__img t-img' data-original='images/tild3438-3130-4261-b936-613465653239__noroot.png' imgfield='tn_img_1673220645079'></div></div> <div class='t396__elem tn-elem tn-elem__5350304951673220665756' data-elem-id='1673220665756' data-elem-type='image' data-field-top-value="16" data-field-left-value="932" data-field-width-value="200" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-filewidth-value="512" data-field-fileheight-value="511" 
><div class='tn-atom' ><img class='tn-atom__img t-img' data-original='images/tild3263-6537-4833-b939-623566366238__noroot.png' imgfield='tn_img_1673220665756'></div></div> <div class='t396__elem tn-elem tn-elem__5350304951673220683538' data-elem-id='1673220683538' data-elem-type='image' data-field-top-value="25" data-field-left-value="650" data-field-width-value="160" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-filewidth-value="512" data-field-fileheight-value="511" 
><div class='tn-atom' ><img class='tn-atom__img t-img' data-original='images/tild3034-3730-4962-a562-393965396161__noroot.png' imgfield='tn_img_1673220683538'></div></div> </div> </div> <script>t_onReady(function () {
t_onFuncLoad('t396_init', function () {
t396_init('535030495');
});
<div>
<div class="container">
<div class="block-row">
<?php
        $link=mysqli_connect("localhost", "root", "root", "kyrsach");
        $query = "select cena, opis,status from info";
        if($result =$link->query($query))
        {
            $rowsCount = $result->num_rows;
        }
        
        foreach($result as $row)
        {
       
                 
    echo "<div class='block'>";
        echo "<h2>".$row["status"]."</h2>";

        echo "<div class='opis'>";
            echo "<p>".$row["opis"]."</p>";
        echo "</div>";

        echo  "<div class='status'>";
            echo "<b>".$row["cena"]."</b>";
        echo "</div>";
    echo "</div>";

                    
        
        }


        ?>
        </div>
</div>

<div>
    <a href="autr.php">Войти</a>
</div>

<div class="container">
<div class="block-row">
<?php
        $link=mysqli_connect("localhost", "root", "root", "kyrsach");
        $query = "select cena, opis,status from info";
        if($result =$link->query($query))
        {
            $rowsCount = $result->num_rows;
        }
        
        foreach($result as $row)
        {
       
                 
    echo "<div class='block'>";
        echo "<h2>".$row["status"]."</h2>";

        echo "<div class='opis'>";
            echo "<p>".$row["opis"]."</p>";
        echo "</div>";

        echo  "<div class='status'>";
            echo "<b>".$row["cena"]."</b>";
        echo "</div>";
    echo "</div>";

                    
        
        }


        ?>
<div>
</div>
<div>
<div class="container2">
<div class="block-row2">
<?php
        $link=mysqli_connect("localhost", "root", "root", "kyrsach");
        $query = "select name from proizv";
        if($result =$link->query($query))
        {
            $rowsCount = $result->num_rows;
        }
        
        foreach($result as $row)
        {
       
                 
    echo "<div class='block2'>";
        echo "<h2>".$row["name"]."</h2>";
    echo "</div>";

                    
        
        }


        ?>
<div>
</div>
</div>
<div>
    <div>
        <?php
        $link=mysqli_connect("localhost", "root", "root", "kyrsach");
        $results = $mysqli->query('SELECT COUNT(`Имя`) FROM `user`');

        $rows = $results->fetch_array();
        
        print_r($rows);
        
        $mysqli->close();
        ?>
    </div>
</div>



















<script>t_onReady(function () {
t_onFuncLoad('t396_init', function () {
t396_init('535033018');
});
});</script><!-- /T396 --></div><div id="rec535033263" class="r t-rec" style=" " data-animationappear="off" data-record-type="396" ><!-- T396 --><style>#rec535033263 .t396__artboard {height: 300px; background-color: #ffffff; }#rec535033263 .t396__filter {height: 300px; }#rec535033263 .t396__carrier{height: 300px; background-position: center center; background-attachment: scroll;background-size: cover;background-repeat: no-repeat;}@media screen and (max-width: 1199px) {#rec535033263 .t396__artboard {}#rec535033263 .t396__filter {}#rec535033263 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 959px) {#rec535033263 .t396__artboard {}#rec535033263 .t396__filter {}#rec535033263 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 639px) {#rec535033263 .t396__artboard {}#rec535033263 .t396__filter {}#rec535033263 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 479px) {#rec535033263 .t396__artboard {}#rec535033263 .t396__filter {}#rec535033263 .t396__carrier {background-attachment: scroll;}} #rec535033263 .tn-elem[data-elem-id="1673221062783"] { z-index: 1; top: 20px;left: calc(50% - 600px + 20px);width: 200px;}#rec535033263 .tn-elem[data-elem-id="1673221062783"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033263 .tn-elem[data-elem-id="1673221062783"] {left: calc(50% - 320px + 100px);}}@media screen and (max-width: 639px) {#rec535033263 .tn-elem[data-elem-id="1673221062783"] {left: calc(50% - 240px + 20px);}}@media screen and (max-width: 479px) {#rec535033263 .tn-elem[data-elem-id="1673221062783"] {left: calc(50% - 160px + 60px);}} #rec535033263 .tn-elem[data-elem-id="1673221067936"] { color: #000000; z-index: 2; top: 20px;left: calc(50% - 600px + 20px);width: 10px;}#rec535033263 .tn-elem[data-elem-id="1673221067936"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033263 .tn-elem[data-elem-id="1673221067936"] {left: calc(50% - 320px + 100px);}}@media screen and (max-width: 639px) {#rec535033263 .tn-elem[data-elem-id="1673221067936"] {left: calc(50% - 240px + 20px);}}@media screen and (max-width: 479px) {#rec535033263 .tn-elem[data-elem-id="1673221067936"] {left: calc(50% - 160px + 60px);}} #rec535033263 .tn-elem[data-elem-id="1673221075307"] { color: #000000; z-index: 3; top: 220px;left: calc(50% - 600px + 94px);width: 50px;}#rec535033263 .tn-elem[data-elem-id="1673221075307"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033263 .tn-elem[data-elem-id="1673221075307"] {left: calc(50% - 320px + 174px);}}@media screen and (max-width: 639px) {#rec535033263 .tn-elem[data-elem-id="1673221075307"] {left: calc(50% - 240px + 94px);}}@media screen and (max-width: 479px) {#rec535033263 .tn-elem[data-elem-id="1673221075307"] {left: calc(50% - 160px + 134px);}} #rec535033263 .tn-elem[data-elem-id="1673221103920"] { color: #000000; z-index: 4; top: 245px;left: calc(50% - 600px + 70px);width: 1px;}#rec535033263 .tn-elem[data-elem-id="1673221103920"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033263 .tn-elem[data-elem-id="1673221103920"] {left: calc(50% - 320px + 150px);}}@media screen and (max-width: 639px) {#rec535033263 .tn-elem[data-elem-id="1673221103920"] {left: calc(50% - 240px + 70px);}}@media screen and (max-width: 479px) {#rec535033263 .tn-elem[data-elem-id="1673221103920"] {left: calc(50% - 160px + 110px);}} #rec535033263 .tn-elem[data-elem-id="1673221125448"] { z-index: 5; top: 20px;left: calc(50% - 600px + 260px);width: 200px;}#rec535033263 .tn-elem[data-elem-id="1673221125448"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033263 .tn-elem[data-elem-id="1673221125448"] {left: calc(50% - 320px + 340px);}}@media screen and (max-width: 639px) {#rec535033263 .tn-elem[data-elem-id="1673221125448"] {left: calc(50% - 240px + 260px);}}@media screen and (max-width: 479px) {#rec535033263 .tn-elem[data-elem-id="1673221125448"] {top: 45px;left: calc(50% - 160px + 430px);}} #rec535033263 .tn-elem[data-elem-id="1673221125454"] { color: #000000; z-index: 6; top: 20px;left: calc(50% - 600px + 260px);width: 10px;}#rec535033263 .tn-elem[data-elem-id="1673221125454"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033263 .tn-elem[data-elem-id="1673221125454"] {left: calc(50% - 320px + 340px);}}@media screen and (max-width: 639px) {#rec535033263 .tn-elem[data-elem-id="1673221125454"] {left: calc(50% - 240px + 260px);}}@media screen and (max-width: 479px) {#rec535033263 .tn-elem[data-elem-id="1673221125454"] {top: 45px;left: calc(50% - 160px + 430px);}} #rec535033263 .tn-elem[data-elem-id="1673221125457"] { color: #000000; z-index: 7; top: 220px;left: calc(50% - 600px + 334px);width: 50px;}#rec535033263 .tn-elem[data-elem-id="1673221125457"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033263 .tn-elem[data-elem-id="1673221125457"] {left: calc(50% - 320px + 414px);}}@media screen and (max-width: 639px) {#rec535033263 .tn-elem[data-elem-id="1673221125457"] {left: calc(50% - 240px + 334px);}}@media screen and (max-width: 479px) {#rec535033263 .tn-elem[data-elem-id="1673221125457"] {top: 245px;left: calc(50% - 160px + 504px);}} #rec535033263 .tn-elem[data-elem-id="1673221125460"] { color: #000000; z-index: 8; top: 245px;left: calc(50% - 600px + 310px);width: 1px;}#rec535033263 .tn-elem[data-elem-id="1673221125460"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033263 .tn-elem[data-elem-id="1673221125460"] {left: calc(50% - 320px + 390px);}}@media screen and (max-width: 639px) {#rec535033263 .tn-elem[data-elem-id="1673221125460"] {left: calc(50% - 240px + 310px);}}@media screen and (max-width: 479px) {#rec535033263 .tn-elem[data-elem-id="1673221125460"] {top: 270px;left: calc(50% - 160px + 480px);}} #rec535033263 .tn-elem[data-elem-id="1673221129113"] { z-index: 9; top: 20px;left: calc(50% - 600px + 500px);width: 200px;}#rec535033263 .tn-elem[data-elem-id="1673221129113"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033263 .tn-elem[data-elem-id="1673221129113"] {top: 35px;left: calc(50% - 320px + 700px);}}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033263 .tn-elem[data-elem-id="1673221129118"] { color: #000000; z-index: 10; top: 20px;left: calc(50% - 600px + 500px);width: 10px;}#rec535033263 .tn-elem[data-elem-id="1673221129118"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033263 .tn-elem[data-elem-id="1673221129118"] {top: 35px;left: calc(50% - 320px + 700px);}}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033263 .tn-elem[data-elem-id="1673221129121"] { color: #000000; z-index: 11; top: 220px;left: calc(50% - 600px + 574px);width: 50px;}#rec535033263 .tn-elem[data-elem-id="1673221129121"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033263 .tn-elem[data-elem-id="1673221129121"] {top: 235px;left: calc(50% - 320px + 774px);}}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033263 .tn-elem[data-elem-id="1673221129124"] { color: #000000; z-index: 12; top: 245px;left: calc(50% - 600px + 550px);width: 1px;}#rec535033263 .tn-elem[data-elem-id="1673221129124"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033263 .tn-elem[data-elem-id="1673221129124"] {top: 260px;left: calc(50% - 320px + 750px);}}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033263 .tn-elem[data-elem-id="1673221131490"] { z-index: 13; top: 20px;left: calc(50% - 600px + 740px);width: 200px;}#rec535033263 .tn-elem[data-elem-id="1673221131490"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033263 .tn-elem[data-elem-id="1673221131490"] {top: 35px;left: calc(50% - 320px + 940px);}}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033263 .tn-elem[data-elem-id="1673221131495"] { color: #000000; z-index: 14; top: 20px;left: calc(50% - 600px + 740px);width: 10px;}#rec535033263 .tn-elem[data-elem-id="1673221131495"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033263 .tn-elem[data-elem-id="1673221131495"] {top: 35px;left: calc(50% - 320px + 940px);}}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033263 .tn-elem[data-elem-id="1673221131498"] { color: #000000; z-index: 15; top: 220px;left: calc(50% - 600px + 814px);width: 50px;}#rec535033263 .tn-elem[data-elem-id="1673221131498"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033263 .tn-elem[data-elem-id="1673221131498"] {top: 235px;left: calc(50% - 320px + 1014px);}}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033263 .tn-elem[data-elem-id="1673221131501"] { color: #000000; z-index: 16; top: 245px;left: calc(50% - 600px + 790px);width: 1px;}#rec535033263 .tn-elem[data-elem-id="1673221131501"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033263 .tn-elem[data-elem-id="1673221131501"] {top: 260px;left: calc(50% - 320px + 990px);}}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033263 .tn-elem[data-elem-id="1673221134943"] { z-index: 17; top: 20px;left: calc(50% - 600px + 970px);width: 200px;}#rec535033263 .tn-elem[data-elem-id="1673221134943"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec535033263 .tn-elem[data-elem-id="1673221134943"] {top: 140px;left: calc(50% - 480px + 1220px);}}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033263 .tn-elem[data-elem-id="1673221134948"] { color: #000000; z-index: 18; top: 20px;left: calc(50% - 600px + 970px);width: 10px;}#rec535033263 .tn-elem[data-elem-id="1673221134948"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec535033263 .tn-elem[data-elem-id="1673221134948"] {top: 140px;left: calc(50% - 480px + 1220px);}}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033263 .tn-elem[data-elem-id="1673221134951"] { color: #000000; z-index: 19; top: 220px;left: calc(50% - 600px + 1044px);width: 50px;}#rec535033263 .tn-elem[data-elem-id="1673221134951"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec535033263 .tn-elem[data-elem-id="1673221134951"] {top: 340px;left: calc(50% - 480px + 1294px);}}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033263 .tn-elem[data-elem-id="1673221134955"] { color: #000000; z-index: 20; top: 245px;left: calc(50% - 600px + 1020px);width: 1px;}#rec535033263 .tn-elem[data-elem-id="1673221134955"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec535033263 .tn-elem[data-elem-id="1673221134955"] {top: 365px;left: calc(50% - 480px + 1270px);}}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {}</style><div class='t396'><div class="t396__artboard" data-artboard-recid="535033263" data-artboard-screens="320,480,640,960,1200" data-artboard-height="300" data-artboard-valign="center" data-artboard-upscale="grid" 
> <script>t_onReady(function () {
t_onFuncLoad('t396_init', function () {
t396_init('535033263');
});
});</script><!-- /T396 --></div><div id="rec535033267" class="r t-rec" style=" " data-animationappear="off" data-record-type="396" ><!-- T396 --><style>#rec535033267 .t396__artboard {height: 300px; background-color: #ffffff; }#rec535033267 .t396__filter {height: 300px; }#rec535033267 .t396__carrier{height: 300px; background-position: center center; background-attachment: scroll;background-size: cover;background-repeat: no-repeat;}@media screen and (max-width: 1199px) {#rec535033267 .t396__artboard {}#rec535033267 .t396__filter {}#rec535033267 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 959px) {#rec535033267 .t396__artboard {}#rec535033267 .t396__filter {}#rec535033267 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 639px) {#rec535033267 .t396__artboard {}#rec535033267 .t396__filter {}#rec535033267 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 479px) {#rec535033267 .t396__artboard {}#rec535033267 .t396__filter {}#rec535033267 .t396__carrier {background-attachment: scroll;}} #rec535033267 .tn-elem[data-elem-id="1673221062783"] { z-index: 1; top: 20px;left: calc(50% - 600px + 20px);width: 200px;}#rec535033267 .tn-elem[data-elem-id="1673221062783"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033267 .tn-elem[data-elem-id="1673221062783"] {left: calc(50% - 320px + 100px);}}@media screen and (max-width: 639px) {#rec535033267 .tn-elem[data-elem-id="1673221062783"] {left: calc(50% - 240px + 20px);}}@media screen and (max-width: 479px) {#rec535033267 .tn-elem[data-elem-id="1673221062783"] {left: calc(50% - 160px + 60px);}} #rec535033267 .tn-elem[data-elem-id="1673221067936"] { color: #000000; z-index: 2; top: 20px;left: calc(50% - 600px + 20px);width: 10px;}#rec535033267 .tn-elem[data-elem-id="1673221067936"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033267 .tn-elem[data-elem-id="1673221067936"] {left: calc(50% - 320px + 100px);}}@media screen and (max-width: 639px) {#rec535033267 .tn-elem[data-elem-id="1673221067936"] {left: calc(50% - 240px + 20px);}}@media screen and (max-width: 479px) {#rec535033267 .tn-elem[data-elem-id="1673221067936"] {left: calc(50% - 160px + 60px);}} #rec535033267 .tn-elem[data-elem-id="1673221075307"] { color: #000000; z-index: 3; top: 220px;left: calc(50% - 600px + 94px);width: 50px;}#rec535033267 .tn-elem[data-elem-id="1673221075307"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033267 .tn-elem[data-elem-id="1673221075307"] {left: calc(50% - 320px + 174px);}}@media screen and (max-width: 639px) {#rec535033267 .tn-elem[data-elem-id="1673221075307"] {left: calc(50% - 240px + 94px);}}@media screen and (max-width: 479px) {#rec535033267 .tn-elem[data-elem-id="1673221075307"] {left: calc(50% - 160px + 134px);}} #rec535033267 .tn-elem[data-elem-id="1673221103920"] { color: #000000; z-index: 4; top: 245px;left: calc(50% - 600px + 70px);width: 1px;}#rec535033267 .tn-elem[data-elem-id="1673221103920"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033267 .tn-elem[data-elem-id="1673221103920"] {left: calc(50% - 320px + 150px);}}@media screen and (max-width: 639px) {#rec535033267 .tn-elem[data-elem-id="1673221103920"] {left: calc(50% - 240px + 70px);}}@media screen and (max-width: 479px) {#rec535033267 .tn-elem[data-elem-id="1673221103920"] {left: calc(50% - 160px + 110px);}} #rec535033267 .tn-elem[data-elem-id="1673221125448"] { z-index: 5; top: 20px;left: calc(50% - 600px + 260px);width: 200px;}#rec535033267 .tn-elem[data-elem-id="1673221125448"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033267 .tn-elem[data-elem-id="1673221125448"] {left: calc(50% - 320px + 340px);}}@media screen and (max-width: 639px) {#rec535033267 .tn-elem[data-elem-id="1673221125448"] {left: calc(50% - 240px + 260px);}}@media screen and (max-width: 479px) {#rec535033267 .tn-elem[data-elem-id="1673221125448"] {top: 45px;left: calc(50% - 160px + 430px);}} #rec535033267 .tn-elem[data-elem-id="1673221125454"] { color: #000000; z-index: 6; top: 20px;left: calc(50% - 600px + 260px);width: 10px;}#rec535033267 .tn-elem[data-elem-id="1673221125454"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033267 .tn-elem[data-elem-id="1673221125454"] {left: calc(50% - 320px + 340px);}}@media screen and (max-width: 639px) {#rec535033267 .tn-elem[data-elem-id="1673221125454"] {left: calc(50% - 240px + 260px);}}@media screen and (max-width: 479px) {#rec535033267 .tn-elem[data-elem-id="1673221125454"] {top: 45px;left: calc(50% - 160px + 430px);}} #rec535033267 .tn-elem[data-elem-id="1673221125457"] { color: #000000; z-index: 7; top: 220px;left: calc(50% - 600px + 334px);width: 50px;}#rec535033267 .tn-elem[data-elem-id="1673221125457"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033267 .tn-elem[data-elem-id="1673221125457"] {left: calc(50% - 320px + 414px);}}@media screen and (max-width: 639px) {#rec535033267 .tn-elem[data-elem-id="1673221125457"] {left: calc(50% - 240px + 334px);}}@media screen and (max-width: 479px) {#rec535033267 .tn-elem[data-elem-id="1673221125457"] {top: 245px;left: calc(50% - 160px + 504px);}} #rec535033267 .tn-elem[data-elem-id="1673221125460"] { color: #000000; z-index: 8; top: 245px;left: calc(50% - 600px + 310px);width: 1px;}#rec535033267 .tn-elem[data-elem-id="1673221125460"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033267 .tn-elem[data-elem-id="1673221125460"] {left: calc(50% - 320px + 390px);}}@media screen and (max-width: 639px) {#rec535033267 .tn-elem[data-elem-id="1673221125460"] {left: calc(50% - 240px + 310px);}}@media screen and (max-width: 479px) {#rec535033267 .tn-elem[data-elem-id="1673221125460"] {top: 270px;left: calc(50% - 160px + 480px);}} #rec535033267 .tn-elem[data-elem-id="1673221129113"] { z-index: 9; top: 20px;left: calc(50% - 600px + 500px);width: 200px;}#rec535033267 .tn-elem[data-elem-id="1673221129113"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033267 .tn-elem[data-elem-id="1673221129113"] {top: 35px;left: calc(50% - 320px + 700px);}}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033267 .tn-elem[data-elem-id="1673221129118"] { color: #000000; z-index: 10; top: 20px;left: calc(50% - 600px + 500px);width: 10px;}#rec535033267 .tn-elem[data-elem-id="1673221129118"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033267 .tn-elem[data-elem-id="1673221129118"] {top: 35px;left: calc(50% - 320px + 700px);}}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033267 .tn-elem[data-elem-id="1673221129121"] { color: #000000; z-index: 11; top: 220px;left: calc(50% - 600px + 574px);width: 50px;}#rec535033267 .tn-elem[data-elem-id="1673221129121"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033267 .tn-elem[data-elem-id="1673221129121"] {top: 235px;left: calc(50% - 320px + 774px);}}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033267 .tn-elem[data-elem-id="1673221129124"] { color: #000000; z-index: 12; top: 245px;left: calc(50% - 600px + 550px);width: 1px;}#rec535033267 .tn-elem[data-elem-id="1673221129124"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033267 .tn-elem[data-elem-id="1673221129124"] {top: 260px;left: calc(50% - 320px + 750px);}}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033267 .tn-elem[data-elem-id="1673221131490"] { z-index: 13; top: 20px;left: calc(50% - 600px + 740px);width: 200px;}#rec535033267 .tn-elem[data-elem-id="1673221131490"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033267 .tn-elem[data-elem-id="1673221131490"] {top: 35px;left: calc(50% - 320px + 940px);}}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033267 .tn-elem[data-elem-id="1673221131495"] { color: #000000; z-index: 14; top: 20px;left: calc(50% - 600px + 740px);width: 10px;}#rec535033267 .tn-elem[data-elem-id="1673221131495"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033267 .tn-elem[data-elem-id="1673221131495"] {top: 35px;left: calc(50% - 320px + 940px);}}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033267 .tn-elem[data-elem-id="1673221131498"] { color: #000000; z-index: 15; top: 220px;left: calc(50% - 600px + 814px);width: 50px;}#rec535033267 .tn-elem[data-elem-id="1673221131498"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033267 .tn-elem[data-elem-id="1673221131498"] {top: 235px;left: calc(50% - 320px + 1014px);}}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033267 .tn-elem[data-elem-id="1673221131501"] { color: #000000; z-index: 16; top: 245px;left: calc(50% - 600px + 790px);width: 1px;}#rec535033267 .tn-elem[data-elem-id="1673221131501"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {#rec535033267 .tn-elem[data-elem-id="1673221131501"] {top: 260px;left: calc(50% - 320px + 990px);}}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033267 .tn-elem[data-elem-id="1673221134943"] { z-index: 17; top: 20px;left: calc(50% - 600px + 970px);width: 200px;}#rec535033267 .tn-elem[data-elem-id="1673221134943"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec535033267 .tn-elem[data-elem-id="1673221134943"] {top: 140px;left: calc(50% - 480px + 1220px);}}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033267 .tn-elem[data-elem-id="1673221134948"] { color: #000000; z-index: 18; top: 20px;left: calc(50% - 600px + 970px);width: 10px;}#rec535033267 .tn-elem[data-elem-id="1673221134948"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec535033267 .tn-elem[data-elem-id="1673221134948"] {top: 140px;left: calc(50% - 480px + 1220px);}}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033267 .tn-elem[data-elem-id="1673221134951"] { color: #000000; z-index: 19; top: 220px;left: calc(50% - 600px + 1044px);width: 50px;}#rec535033267 .tn-elem[data-elem-id="1673221134951"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec535033267 .tn-elem[data-elem-id="1673221134951"] {top: 340px;left: calc(50% - 480px + 1294px);}}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033267 .tn-elem[data-elem-id="1673221134955"] { color: #000000; z-index: 20; top: 245px;left: calc(50% - 600px + 1020px);width: 1px;}#rec535033267 .tn-elem[data-elem-id="1673221134955"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec535033267 .tn-elem[data-elem-id="1673221134955"] {top: 365px;left: calc(50% - 480px + 1270px);}}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {}</style><div class='t396'><div class="t396__artboard" data-artboard-recid="535033267" data-artboard-screens="320,480,640,960,1200" data-artboard-height="300" data-artboard-valign="center" data-artboard-upscale="grid" 
><script>t_onReady(function () {
t_onFuncLoad('t396_init', function () {
t396_init('535033267');
});
});</script><!-- /T396 --></div><div id="rec535033392" class="r t-rec" style=" " data-animationappear="off" data-record-type="396" ><!-- T396 --><style>#rec535033392 .t396__artboard {height: 700px; background-color: #ffffff; }#rec535033392 .t396__filter {height: 700px; }#rec535033392 .t396__carrier{height: 700px; background-position: center center; background-attachment: scroll;background-size: cover;background-repeat: no-repeat;}@media screen and (max-width: 1199px) {#rec535033392 .t396__artboard {}#rec535033392 .t396__filter {}#rec535033392 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 959px) {#rec535033392 .t396__artboard {}#rec535033392 .t396__filter {}#rec535033392 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 639px) {#rec535033392 .t396__artboard {}#rec535033392 .t396__filter {}#rec535033392 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 479px) {#rec535033392 .t396__artboard {}#rec535033392 .t396__filter {}#rec535033392 .t396__carrier {background-attachment: scroll;}} #rec535033392 .tn-elem[data-elem-id="1673221226811"] { color: #000000; z-index: 1; top: 20px;left: calc(50% - 600px + 20px);width: 560px;}#rec535033392 .tn-elem[data-elem-id="1673221226811"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033392 .tn-elem[data-elem-id="1673221235731"] { color: #000000; z-index: 2; top: 82px;left: calc(50% - 600px + 20px);width: 560px;}#rec535033392 .tn-elem[data-elem-id="1673221235731"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033392 .tn-elem[data-elem-id="1673221246506"] { color: #000000; z-index: 3; top: 215px;left: calc(50% - 600px + 20px);width: 560px;}#rec535033392 .tn-elem[data-elem-id="1673221246506"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033392 .tn-elem[data-elem-id="1673221265790"] { color: #000000; z-index: 4; top: 20px;left: calc(50% - 600px + 640px);width: 560px;}#rec535033392 .tn-elem[data-elem-id="1673221265790"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {} #rec535033392 .tn-elem[data-elem-id="1673221273573"] { z-index: 5; top: 390px;left: calc(50% - 600px + 780px);width: 262px;}#rec535033392 .tn-elem[data-elem-id="1673221273573"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {}@media screen and (max-width: 479px) {}</style><div class='t396'><div class="t396__artboard" data-artboard-recid="535033392" data-artboard-screens="320,480,640,960,1200" data-artboard-height="700" data-artboard-valign="center" data-artboard-upscale="grid" 
><div class="t396__carrier" data-artboard-recid="535033392"></div><div class="t396__filter" data-artboard-recid="535033392"></div><div class='t396__elem tn-elem tn-elem__5350333921673221226811' data-elem-id='1673221226811' data-elem-type='text' data-field-top-value="20" data-field-left-value="20" data-field-width-value="560" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px"
><div class='tn-atom'field='tn_text_1673221226811'><strong>Торговое оборудование для магазинов, супермаркетов, общепитов в Гродно и всей Беларуси</strong></div> </div> <div class='t396__elem tn-elem tn-elem__5350333921673221235731' data-elem-id='1673221235731' data-elem-type='text' data-field-top-value="82" data-field-left-value="20" data-field-width-value="560" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px"
><div class='tn-atom'field='tn_text_1673221235731'>Большое значение в успехе магазина имеет подбор, расстановка, монтаж, последующее обслуживание торгового и технологического оборудования. Свою помощь в этом предлагает Вам компания "NePROD".</div> </div> <div class='t396__elem tn-elem tn-elem__5350333921673221246506' data-elem-id='1673221246506' data-elem-type='text' data-field-top-value="215" data-field-left-value="20" data-field-width-value="560" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px"
><div class='tn-atom'field='tn_text_1673221246506'><strong>Цена на торговое оборудование в интернет-магазине NePROD</strong><br>Продажа стеллажей и холодильных витрин в Беларуси осуществляется на основе выставления максимально доступных цен. Уменьшать стоимость продукции нам позволяет тесное сотрудничество с партнерами-производителями, а также эффективная логистика.<br>Цены формируются исходя из вида, размеров, особенностей оснащения, бренда-производителя, объема заказа, нужных опций, необходимости предоставления сопутствующих услуг (доставки, монтажа, наладки, сервисного контроля). Каждая поставка индивидуальна, зависит от потребности, предпочтения, возможностей клиента.</div> </div> <div class='t396__elem tn-elem tn-elem__5350333921673221265790' data-elem-id='1673221265790' data-elem-type='text' data-field-top-value="20" data-field-left-value="640" data-field-width-value="560" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px"
><div class='tn-atom'field='tn_text_1673221265790'><strong>Ассортимент, типы</strong><br>Предлагает купить технологическое оборудование широкого профиля. В каталогах фирмы:<br><ul><li><a href="https://bth.by/catalog/universal-metal-systems/">торговые</a>, <a href="https://bth.by/catalog/for-sale-vegetables-and-fruits/">овощные</a>, <a href="https://bth.by/catalog/stellazhi-arkhivno-skladskie/?iswebp&amp;clear_cache=Y">складские стеллажи</a>, мебель;</li><li><a href="https://bth.by/catalog/equipment/">холодильники для магазинов</a>;</li><li><a href="https://bth.by/catalog/for-stores-non-foof/">стенды для одежды</a>;</li><li><a href="https://bth.by/catalog/konditerskaya/">кондитерские</a>, <a href="https://bth.by/catalog/vitrina-teplovaya/">тепловые</a>, <a href="https://bth.by/catalog/showcase-wall/">пристенные</a>, <a href="https://bth.by/catalog/vitrina-khlebnaya/">хлебные</a> и <a href="https://bth.by/catalog/showcase/">холодильные витрины</a>;</li><li><a href="https://bth.by/catalog/checkouts/">кассовые боксы</a>;</li><li><a href="https://bth.by/catalog/telezhki-i-korzinki-dlya-pokupateley/">акционные, покупательские корзины, тележки</a>;</li><li><a href="https://bth.by/catalog/individual-heating-system-and-fencing/">турникеты, проходные системы</a>.</li></ul></div> </div> <div class='t396__elem tn-elem tn-elem__5350333921673221273573' data-elem-id='1673221273573' data-elem-type='image' data-field-top-value="390" data-field-left-value="780" data-field-width-value="262" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px"
><div class='tn-atom' ><img class='tn-atom__img t-img' data-original='https://tilda.ws/img/imgfishsquare.gif' imgfield='tn_img_1673221273573'></div></div> </div> </div> <script>t_onReady(function () {
t_onFuncLoad('t396_init', function () {
t396_init('535033392');
});
});</script><!-- /T396 --></div><!--footer--><div id="t-footer" class="t-records" data-hook="blocks-collection-content-node" data-tilda-project-id="1465553" data-tilda-page-id="6697690" data-tilda-formskey="a0b3ebc6b7338134a33eca4420b48dce" data-tilda-lazy="yes"><div id="rec229687046" class="r t-rec" style="background-color:#f9f9f9; " data-record-type="702" data-bg-color="#f9f9f9"><!-- T702 --><div class="t702"><div class="t-popup" data-tooltip-hook="#popup:order" data-track-popup='/tilda/popup/rec229687046/opened' 
role="dialog" 
aria-modal="true" 
tabindex="-1"
aria-label="Заказать дизайн формы" ><div class="t-popup__container t-width t-width_6" style="background-color:#f9f9f9;"><div class="t702__wrapper"><div class="t702__text-wrapper t-align_center"><div class="t702__title t-title t-title_xxs" style="color:#262a2d;font-size:18px;font-weight:600;font-family:'museo';">Заказать дизайн формы</div></div> <form id="form229687046" name='form229687046' role="form" action='' method='POST' data-formactiontype="2" data-inputbox=".t-input-group" class="t-form js-form-proccess t-form_inputs-total_5 t-form_bbonly " data-success-callback="t702_onSuccess" ><input type="hidden" name="formservices[]" value="1d2cf8d34316b60f0d3aace50524d3a2" class="js-formaction-services"><input type="hidden" name="formservices[]" value="df6c6fba2d0d34ccc891d207ce871964" class="js-formaction-services"><input type="hidden" name="tildaspec-formname" tabindex="-1" value="main_page_order"><div class="js-successbox t-form__successbox t-text t-text_md" style="display:none;color:#262a2d;">Спасибо! Мы скоро свяжемся.</div><div class="t-form__inputsbox"><div class="t-input-group t-input-group_nm" data-input-lid="1495810354468"><div class="t-input-title t-descr t-descr_md" data-redactor-toolbar="no" field="li_title__1495810354468" style="font-weight:500;">Имя</div> <div class="t-input-block"><input type="text" autocomplete="name" name="Name" class="t-input js-tilda-rule t-input_bbonly" value="" data-tilda-req="1" data-tilda-rule="name" style="color:#262a2d; border:1px solid #262a2d; "><div class="t-input-error"></div></div></div><div class="t-input-group t-input-group_in" data-input-lid="1495810359387"><div class="t-input-title t-descr t-descr_md" data-redactor-toolbar="no" field="li_title__1495810359387" style="font-weight:500;">Viber / WhatsApp / Telegram</div> <div class="t-input-block"><input type="text" name="Viber WhatsApp Telegram" class="t-input js-tilda-rule t-input_bbonly" value="" data-tilda-req="1" style="color:#262a2d; border:1px solid #262a2d; "><div class="t-input-error"></div></div></div><div class="t-input-group t-input-group_em" data-input-lid="1495810410810"><div class="t-input-title t-descr t-descr_md" data-redactor-toolbar="no" field="li_title__1495810410810" style="font-weight:500;">E-mail</div> <div class="t-input-block"><input type="text" autocomplete="email" name="Email" class="t-input js-tilda-rule t-input_bbonly" value="" data-tilda-req="1" data-tilda-rule="email" style="color:#262a2d; border:1px solid #262a2d; "><div class="t-input-error"></div></div></div><div class="t-input-group t-input-group_rg" data-input-lid="1572176014081"><div class="t-input-title t-descr t-descr_md" data-redactor-toolbar="no" field="li_title__1572176014081" style="font-weight:500;">Количество комплектов</div> <div class="t-input-block"><div class="t-range__wrapper"><input name="Количество комплектов_2" class="t-range js-tilda-rule" type="range" min="5" max="30" step="1" value="5" data-range-color="#262a2d"><div class="t-range__value-txt t-descr t-descr_xxs" style="display: none;"></div><div class="t-range__interval-txt-wrapper"><div class="t-range__interval-txt t-range__interval-txt_min t-descr t-descr_xxs" >5</div><div class="t-range__interval-txt t-range__interval-txt_max t-descr t-descr_xxs" >30</div></div></div><link rel="stylesheet" href="css/tilda-range-1.0.min.css"><script src="js/tilda-range-1.0.min.js"></script><script type="text/javascript">t_onReady(function () {
try {
t_onFuncLoad('t_input_range_init', function () {
t_input_range_init('229687046', '1572176014081');
});
} catch (error) {
console.error(error);
}
});</script><style>#rec229687046 .t-range::-webkit-slider-thumb {
background: #262a2d;
}
#rec229687046 .t-range::-moz-range-thumb {
background: #262a2d;
}
#rec229687046 .t-range::-ms-thumb {
background: #262a2d;
}</style><div class="t-input-error"></div></div></div><div class="t-input-group t-input-group_ta" data-input-lid="1564239746961"><div class="t-input-title t-descr t-descr_md" data-redactor-toolbar="no" field="li_title__1564239746961" style="font-weight:500;">Уточнения и пожелания</div> <div class="t-input-block"><textarea name="Уточнения и пожелания" class="t-input js-tilda-rule t-input_bbonly" style="color:#262a2d; border:1px solid #262a2d; height:68px;" rows="2"></textarea><div class="t-input-error"></div></div></div><div class="t-form__errorbox-middle"><div class="js-errorbox-all t-form__errorbox-wrapper" style="display:none;"><div class="t-form__errorbox-text t-text t-text_md"><p class="t-form__errorbox-item js-rule-error js-rule-error-all"></p><p class="t-form__errorbox-item js-rule-error js-rule-error-req"></p><p class="t-form__errorbox-item js-rule-error js-rule-error-email"></p><p class="t-form__errorbox-item js-rule-error js-rule-error-name"></p><p class="t-form__errorbox-item js-rule-error js-rule-error-phone"></p><p class="t-form__errorbox-item js-rule-error js-rule-error-minlength"></p><p class="t-form__errorbox-item js-rule-error js-rule-error-string"></p></div></div> </div><div class="t-form__submit"><button type="submit" class="t-submit" style="color:#262a2d;border:2px solid #eb974e;font-family:museo;font-weight:600;" >отправить</button></div></div><div class="t-form__errorbox-bottom"><div class="js-errorbox-all t-form__errorbox-wrapper" style="display:none;"><div class="t-form__errorbox-text t-text t-text_md"><p class="t-form__errorbox-item js-rule-error js-rule-error-all"></p><p class="t-form__errorbox-item js-rule-error js-rule-error-req"></p><p class="t-form__errorbox-item js-rule-error js-rule-error-email"></p><p class="t-form__errorbox-item js-rule-error js-rule-error-name"></p><p class="t-form__errorbox-item js-rule-error js-rule-error-phone"></p><p class="t-form__errorbox-item js-rule-error js-rule-error-minlength"></p><p class="t-form__errorbox-item js-rule-error js-rule-error-string"></p></div></div> </div></form><style>#rec229687046 input::-webkit-input-placeholder {color:#262a2d; opacity: 0.5;}
#rec229687046 input::-moz-placeholder {color:#262a2d; opacity: 0.5;}
#rec229687046 input:-moz-placeholder {color:#262a2d; opacity: 0.5;}
#rec229687046 input:-ms-input-placeholder {color:#262a2d; opacity: 0.5;}
#rec229687046 textarea::-webkit-input-placeholder {color:#262a2d; opacity: 0.5;}
#rec229687046 textarea::-moz-placeholder {color:#262a2d; opacity: 0.5;}
#rec229687046 textarea:-moz-placeholder {color:#262a2d; opacity: 0.5;}
#rec229687046 textarea:-ms-input-placeholder {color:#262a2d; opacity: 0.5;}</style></div></div><div class="t-popup__close t-popup__block-close"><button type="button" class="t-popup__close-wrapper t-popup__block-close-button" aria-label="Закрыть диалог"><svg role="presentation" class="t-popup__close-icon" width="23px" height="23px" viewBox="0 0 23 23" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g stroke="none" stroke-width="1" fill="#454c51" fill-rule="evenodd"><rect transform="translate(11.313708, 11.313708) rotate(-45.000000) translate(-11.313708, -11.313708) " x="10.3137085" y="-3.6862915" width="2" height="30"></rect><rect transform="translate(11.313708, 11.313708) rotate(-315.000000) translate(-11.313708, -11.313708) " x="10.3137085" y="-3.6862915" width="2" height="30"></rect></g></svg></button></div></div></div><script>t_onReady(function () {
t_onFuncLoad('t702_initPopup', function () {
t702_initPopup('229687046');
});
/* fix for Android */
var ua = navigator.userAgent.toLowerCase();
var isAndroid = ua.indexOf("android") > -1;
if (isAndroid) {
document.querySelector('.t-body').classList.add('t-body_scrollable-fix-for-android');
document.querySelector('head').insertAdjacentHTML('beforeend', '<style>@media screen and (max-width: 560px) {\n.t-body_scrollable-fix-for-android {\noverflow: visible !important;\n}\n}\n</style>');
console.log('Android css fix was inited');
}
});</script><style>#rec229687046 .t-submit:hover{
color: #eb974e !important; } 
#rec229687046 .t-submit{
-webkit-transition: background-color 0.2s ease-in-out, color 0.2s ease-in-out, border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out; transition: background-color 0.2s ease-in-out, color 0.2s ease-in-out, border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
}</style></div><div id="rec127585265" class="r t-rec" style=" " data-animationappear="off" data-record-type="396" ><!-- T396 --><style>#rec127585265 .t396__artboard {height: 269px; background-color: #394045; }#rec127585265 .t396__filter {height: 269px; }#rec127585265 .t396__carrier{height: 269px; background-position: center center; background-attachment: scroll;background-size: cover;background-repeat: no-repeat;}@media screen and (max-width: 1199px) {#rec127585265 .t396__artboard {}#rec127585265 .t396__filter {}#rec127585265 .t396__carrier {background-attachment: scroll;}}@media screen and (max-width: 959px) {#rec127585265 .t396__artboard {height: 509px;}#rec127585265 .t396__filter {height: 509px;}#rec127585265 .t396__carrier {height: 509px;background-attachment: scroll;}}@media screen and (max-width: 639px) {#rec127585265 .t396__artboard {height: 719px;}#rec127585265 .t396__filter {height: 719px;}#rec127585265 .t396__carrier {height: 719px;background-attachment: scroll;}}@media screen and (max-width: 479px) {#rec127585265 .t396__artboard {}#rec127585265 .t396__filter {}#rec127585265 .t396__carrier {background-attachment: scroll;}} #rec127585265 .tn-elem[data-elem-id="1563200101705"] { color: #000000; z-index: 13; top: 10px;left: calc(50% - 600px + 120px);width: 560px;}#rec127585265 .tn-elem[data-elem-id="1563200101705"] .tn-atom { color: #000000; font-size: 20px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1563200101705"] {top: 35px;left: calc(50% - 240px + 120px);}}@media screen and (max-width: 479px) {} #rec127585265 .tn-elem[data-elem-id="1564026075765"] { color: #f9f9f9; z-index: 14; top: 45px;left: calc(50% - 600px + 720px);width: 119px;}#rec127585265 .tn-elem[data-elem-id="1564026075765"] .tn-atom { color: #f9f9f9; font-size: 14px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 600; letter-spacing: 0.5px; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1564026075765"] {top: 45px;left: calc(50% - 480px + 572px);}}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1564026075765"] {top: 175px;left: calc(50% - 320px + 261px);}#rec127585265 .tn-elem[data-elem-id="1564026075765"] {text-align: center;}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1564026075765"] {top: 279px;left: calc(50% - 240px + 165px);width: 148 px ;}#rec127585265 .tn-elem[data-elem-id="1564026075765"] {text-align: center;}#rec127585265 .tn-elem[data-elem-id="1564026075765"] .tn-atom { font-size: 16px; }}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1564026075765"] {top: 283px;left: calc(50% - 160px + 81px);width: 158 px ;}#rec127585265 .tn-elem[data-elem-id="1564026075765"] .tn-atom { font-size: 16px; }} #rec127585265 .tn-elem[data-elem-id="1564026156227"] { color: #f9f9f9; z-index: 15; top: 80px;left: calc(50% - 600px + 720px);width: 99px;}#rec127585265 .tn-elem[data-elem-id="1564026156227"] .tn-atom { color: #f9f9f9; font-size: 14px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 600; letter-spacing: 0.5px; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1564026156227"] {top: 80px;left: calc(50% - 480px + 572px);}}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1564026156227"] {top: 216px;left: calc(50% - 320px + 271px);}#rec127585265 .tn-elem[data-elem-id="1564026156227"] {text-align: center;}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1564026156227"] {top: 315px;left: calc(50% - 240px + 176px);width: 127 px ;}#rec127585265 .tn-elem[data-elem-id="1564026156227"] {text-align: center;}#rec127585265 .tn-elem[data-elem-id="1564026156227"] .tn-atom { font-size: 16px; }}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1564026156227"] {top: 319px;left: calc(50% - 160px + 97px);width: 127 px ;}#rec127585265 .tn-elem[data-elem-id="1564026156227"] .tn-atom { font-size: 16px; }} #rec127585265 .tn-elem[data-elem-id="1564026170731"] { color: #f9f9f9; z-index: 16; top: 116px;left: calc(50% - 600px + 720px);width: 70px;}#rec127585265 .tn-elem[data-elem-id="1564026170731"] .tn-atom { color: #f9f9f9; font-size: 14px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 600; letter-spacing: 0.5px; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1564026170731"] {top: 116px;left: calc(50% - 480px + 571px);}}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1564026170731"] {top: 257px;left: calc(50% - 320px + 285px);}#rec127585265 .tn-elem[data-elem-id="1564026170731"] {text-align: center;}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1564026170731"] {top: 351px;left: calc(50% - 240px + 200px);}#rec127585265 .tn-elem[data-elem-id="1564026170731"] {text-align: center;}#rec127585265 .tn-elem[data-elem-id="1564026170731"] .tn-atom { font-size: 16px; }}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1564026170731"] {top: 355px;left: calc(50% - 160px + 121px);}#rec127585265 .tn-elem[data-elem-id="1564026170731"] .tn-atom { font-size: 16px; }} #rec127585265 .tn-elem[data-elem-id="1564026287750"] { color: #f9f9f9; z-index: 18; top: 70px;left: calc(50% - 600px + 580px);width: 169px;}#rec127585265 .tn-elem[data-elem-id="1564026287750"] .tn-atom { color: #f9f9f9; font-size: 14px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 600; letter-spacing: 0.5px; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1564026287750"] {top: 95px;left: calc(50% - 240px + 580px);}}@media screen and (max-width: 479px) {} #rec127585265 .tn-elem[data-elem-id="1564026470193"] { color: #f9f9f9; z-index: 20; top: 70px;left: calc(50% - 600px + 580px);width: 188px;}#rec127585265 .tn-elem[data-elem-id="1564026470193"] .tn-atom { color: #f9f9f9; font-size: 14px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 600; letter-spacing: 0.5px; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1564026470193"] {top: 95px;left: calc(50% - 240px + 580px);}}@media screen and (max-width: 479px) {} #rec127585265 .tn-elem[data-elem-id="1564026597469"] { z-index: 21; top: 30px;left: calc(50% - 600px + 20px);width: 60px;}#rec127585265 .tn-elem[data-elem-id="1564026597469"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1564026597469"] {top: 30px;left: calc(50% - 480px + 12px);}}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1564026597469"] {top: 30px;left: calc(50% - 320px + 12px);}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1564026597469"] {top: 47px;left: calc(50% - 240px + 210px);}}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1564026597469"] {top: 55px;left: calc(50% - 160px + 130px);}} #rec127585265 .tn-elem[data-elem-id="1564026629614"] { color: #f9f9f9; z-index: 22; top: 50px;left: calc(50% - 600px + 94px);width: 79px;}#rec127585265 .tn-elem[data-elem-id="1564026629614"] .tn-atom { color: #f9f9f9; font-size: 14px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 600; letter-spacing: 0.5px; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1564026629614"] {top: 50px;left: calc(50% - 480px + 86px);}}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1564026629614"] {top: 95px;left: calc(50% - 320px + 10px);}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1564026629614"] {top: 107px;left: calc(50% - 240px + 201px);}}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1564026629614"] {top: 115px;left: calc(50% - 160px + 121px);}} #rec127585265 .tn-elem[data-elem-id="1564026948737"] { color: #f9f9f9; z-index: 23; top: 50px;left: calc(50% - 600px + 1085px);width: 70px;}#rec127585265 .tn-elem[data-elem-id="1564026948737"] .tn-atom { color: #f9f9f9; font-size: 14px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 600; letter-spacing: 0.5px; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1564026948737"] {top: 50px;left: calc(50% - 480px + 855px);}}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1564026948737"] {top: 90px;left: calc(50% - 320px + 560px);}#rec127585265 .tn-elem[data-elem-id="1564026948737"] {text-align: right;}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1564026948737"] {top: 560px;left: calc(50% - 240px + 205px);}#rec127585265 .tn-elem[data-elem-id="1564026948737"] {text-align: center;}}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1564026948737"] {top: 564px;left: calc(50% - 160px + 125px);}} #rec127585265 .tn-elem[data-elem-id="1564027196614"] { color: #f9f9f9; z-index: 24; top: 180px;left: calc(50% - 600px + 19px);width: 158px;}#rec127585265 .tn-elem[data-elem-id="1564027196614"] .tn-atom { color: #f9f9f9; font-size: 12px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; letter-spacing: 0.5px; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1564027196614"] {top: 180px;left: calc(50% - 480px + 10px);width: 188 px ;}#rec127585265 .tn-elem[data-elem-id="1564027196614"] {text-align: left;}#rec127585265 .tn-elem[data-elem-id="1564027196614"] .tn-atom { font-size: 12px; }}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1564027196614"] {top: 420px;left: calc(50% - 320px + 226px);}#rec127585265 .tn-elem[data-elem-id="1564027196614"] {text-align: center;}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1564027196614"] {top: 628px;left: calc(50% - 240px + 146px);}#rec127585265 .tn-elem[data-elem-id="1564027196614"] {text-align: center;}}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1564027196614"] {top: 632px;left: calc(50% - 160px + 66px);}} #rec127585265 .tn-elem[data-elem-id="1564027337563"] { color: #f9f9f9; text-align: center; z-index: 25; top: 205px;left: calc(50% - 600px + 460px);width: 179px;}#rec127585265 .tn-elem[data-elem-id="1564027337563"] .tn-atom { color: #f9f9f9; font-size: 12px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; letter-spacing: 0.5px; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {}@media screen and (max-width: 959px) {}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1564027337563"] {top: 230px;left: calc(50% - 240px + 460px);}}@media screen and (max-width: 479px) {} #rec127585265 .tn-elem[data-elem-id="1564027379553"] { color: #f9f9f9; z-index: 26; top: 200px;left: calc(50% - 600px + 19px);width: 169px;}#rec127585265 .tn-elem[data-elem-id="1564027379553"] .tn-atom { color: #f9f9f9; font-size: 12px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 400; letter-spacing: 0.5px; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1564027379553"] {top: 200px;left: calc(50% - 480px + 10px);width: 188 px ;}#rec127585265 .tn-elem[data-elem-id="1564027379553"] {text-align: left;}#rec127585265 .tn-elem[data-elem-id="1564027379553"] .tn-atom { font-size: 12px; }}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1564027379553"] {top: 440px;left: calc(50% - 320px + 226px);}#rec127585265 .tn-elem[data-elem-id="1564027379553"] {text-align: center;}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1564027379553"] {top: 648px;left: calc(50% - 240px + 146px);}#rec127585265 .tn-elem[data-elem-id="1564027379553"] {text-align: center;}}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1564027379553"] {top: 652px;left: calc(50% - 160px + 66px);}} #rec127585265 .tn-elem[data-elem-id="1564028213873"] { z-index: 27; top: 46px;left: calc(50% - 600px + 1158px);width: 20px;}#rec127585265 .tn-elem[data-elem-id="1564028213873"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1564028213873"] {top: 46px;left: calc(50% - 480px + 928px);}}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1564028213873"] {top: 38px;left: calc(50% - 320px + 593px);width: 30 px ;}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1564028213873"] {top: 513px;left: calc(50% - 240px + 225px);width: 30 px ;}}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1564028213873"] {top: 517px;left: calc(50% - 160px + 145px);}} #rec127585265 .tn-elem[data-elem-id="1599395073156"] { color: #f9f9f9; z-index: 28; top: 45px;left: calc(50% - 600px + 380px);width: 169px;}#rec127585265 .tn-elem[data-elem-id="1599395073156"] .tn-atom { color: #f9f9f9; font-size: 14px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 600; letter-spacing: 0.5px; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1599395073156"] {top: 45px;left: calc(50% - 480px + 330px);}}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1599395073156"] {top: 52px;left: calc(50% - 320px + 236px);}#rec127585265 .tn-elem[data-elem-id="1599395073156"] {text-align: center;}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1599395073156"] {top: 171px;left: calc(50% - 240px + 131px);width: 217 px ;}#rec127585265 .tn-elem[data-elem-id="1599395073156"] {text-align: center;}#rec127585265 .tn-elem[data-elem-id="1599395073156"] .tn-atom { font-size: 16px; }}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1599395073156"] {top: 175px;left: calc(50% - 160px + 62px);width: 197 px ;}#rec127585265 .tn-elem[data-elem-id="1599395073156"] .tn-atom { font-size: 16px; }} #rec127585265 .tn-elem[data-elem-id="1599395073169"] { color: #f9f9f9; z-index: 29; top: 80px;left: calc(50% - 600px + 380px);width: 99px;}#rec127585265 .tn-elem[data-elem-id="1599395073169"] .tn-atom { color: #f9f9f9; font-size: 14px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 600; letter-spacing: 0.5px; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1599395073169"] {top: 80px;left: calc(50% - 480px + 330px);}}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1599395073169"] {top: 93px;left: calc(50% - 320px + 271px);}#rec127585265 .tn-elem[data-elem-id="1599395073169"] {text-align: center;}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1599395073169"] {top: 207px;left: calc(50% - 240px + 190px);}#rec127585265 .tn-elem[data-elem-id="1599395073169"] {text-align: center;}#rec127585265 .tn-elem[data-elem-id="1599395073169"] .tn-atom { font-size: 16px; }}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1599395073169"] {top: 211px;left: calc(50% - 160px + 111px);}#rec127585265 .tn-elem[data-elem-id="1599395073169"] .tn-atom { font-size: 16px; }} #rec127585265 .tn-elem[data-elem-id="1599395073177"] { color: #f9f9f9; z-index: 30; top: 116px;left: calc(50% - 600px + 380px);width: 70px;}#rec127585265 .tn-elem[data-elem-id="1599395073177"] .tn-atom { color: #f9f9f9; font-size: 14px; font-family: 'museo',Arial,sans-serif; line-height: 1.55; font-weight: 600; letter-spacing: 0.5px; background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1599395073177"] {top: 116px;left: calc(50% - 480px + 330px);}}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1599395073177"] {top: 134px;left: calc(50% - 320px + 285px);}#rec127585265 .tn-elem[data-elem-id="1599395073177"] {text-align: center;}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1599395073177"] {top: 243px;left: calc(50% - 240px + 204px);}#rec127585265 .tn-elem[data-elem-id="1599395073177"] {text-align: center;}#rec127585265 .tn-elem[data-elem-id="1599395073177"] .tn-atom { font-size: 16px; }}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1599395073177"] {top: 247px;left: calc(50% - 160px + 125px);}#rec127585265 .tn-elem[data-elem-id="1599395073177"] .tn-atom { font-size: 16px; }} #rec127585265 .tn-elem[data-elem-id="1599399715476"] { z-index: 31; top: 178px;left: calc(50% - 600px + 1047px);width: 37px;}#rec127585265 .tn-elem[data-elem-id="1599399715476"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1599399715476"] {top: 178px;left: calc(50% - 480px + 813px);}}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1599399715476"] {top: 330px;left: calc(50% - 320px + 301px);}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1599399715476"] {top: 423px;left: calc(50% - 240px + 221px);}}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1599399715476"] {top: 427px;left: calc(50% - 160px + 141px);}} #rec127585265 .tn-elem[data-elem-id="1599399903615"] { z-index: 32; top: 179px;left: calc(50% - 600px + 948px);width: 35px;}#rec127585265 .tn-elem[data-elem-id="1599399903615"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1599399903615"] {top: 179px;left: calc(50% - 480px + 714px);}}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1599399903615"] {top: 331px;left: calc(50% - 320px + 191px);}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1599399903615"] {top: 424px;left: calc(50% - 240px + 111px);}}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1599399903615"] {top: 428px;left: calc(50% - 160px + 21px);}} #rec127585265 .tn-elem[data-elem-id="1599399920662"] { z-index: 33; top: 179px;left: calc(50% - 600px + 1096px);width: 35px;}#rec127585265 .tn-elem[data-elem-id="1599399920662"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1599399920662"] {top: 179px;left: calc(50% - 480px + 862px);}}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1599399920662"] {top: 331px;left: calc(50% - 320px + 357px);}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1599399920662"] {top: 424px;left: calc(50% - 240px + 277px);}}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1599399920662"] {top: 428px;left: calc(50% - 160px + 202px);}} #rec127585265 .tn-elem[data-elem-id="1599399936487"] { z-index: 34; top: 178px;left: calc(50% - 600px + 1145px);width: 37px;}#rec127585265 .tn-elem[data-elem-id="1599399936487"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1599399936487"] {top: 178px;left: calc(50% - 480px + 911px);}}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1599399936487"] {top: 330px;left: calc(50% - 320px + 412px);}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1599399936487"] {top: 423px;left: calc(50% - 240px + 332px);}}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1599399936487"] {top: 427px;left: calc(50% - 160px + 262px);}} #rec127585265 .tn-elem[data-elem-id="1599399948601"] { z-index: 35; top: 180px;left: calc(50% - 600px + 998px);width: 35px;}#rec127585265 .tn-elem[data-elem-id="1599399948601"] .tn-atom {background-position: center center ;border-color: transparent ;border-style: solid ;}@media screen and (max-width: 1199px) {#rec127585265 .tn-elem[data-elem-id="1599399948601"] {top: 180px;left: calc(50% - 480px + 764px);}}@media screen and (max-width: 959px) {#rec127585265 .tn-elem[data-elem-id="1599399948601"] {top: 332px;left: calc(50% - 320px + 246px);}}@media screen and (max-width: 639px) {#rec127585265 .tn-elem[data-elem-id="1599399948601"] {top: 425px;left: calc(50% - 240px + 166px);}}@media screen and (max-width: 479px) {#rec127585265 .tn-elem[data-elem-id="1599399948601"] {top: 429px;left: calc(50% - 160px + 81px);}}</style><div class='t396'><div class="t396__artboard" data-artboard-recid="127585265" data-artboard-screens="320,480,640,960,1200" data-artboard-height="269" data-artboard-valign="center" data-artboard-upscale="grid" data-artboard-height-res-480="719" data-artboard-height-res-640="509" 
><div class="t396__carrier" data-artboard-recid="127585265"></div><div class="t396__filter" data-artboard-recid="127585265"></div><div class='t396__elem tn-elem tn-elem__1275852651563200101705' data-elem-id='1563200101705' data-elem-type='text' data-field-top-value="10" data-field-left-value="120" data-field-width-value="560" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-480-value="35" data-field-left-res-480-value="120" 
><div class='tn-atom'field='tn_text_1563200101705'></div> </div> <div class='t396__elem tn-elem tn-elem__1275852651564026075765' data-elem-id='1564026075765' data-elem-type='text' data-field-top-value="45" data-field-left-value="720" data-field-width-value="119" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="283" data-field-left-res-320-value="81" data-field-width-res-320-value="158" data-field-top-res-480-value="279" data-field-left-res-480-value="165" data-field-width-res-480-value="148" data-field-top-res-640-value="175" data-field-left-res-640-value="261" data-field-top-res-960-value="45" data-field-left-res-960-value="572" 
><div class='tn-atom'><a href="http://combasketteam.ru/examples"style="color: inherit">Больше информации<br></a></div> </div> <div class='t396__elem tn-elem tn-elem__1275852651564026156227' data-elem-id='1564026156227' data-elem-type='text' data-field-top-value="80" data-field-left-value="720" data-field-width-value="99" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="319" data-field-left-res-320-value="97" data-field-width-res-320-value="127" data-field-top-res-480-value="315" data-field-left-res-480-value="176" data-field-width-res-480-value="127" data-field-top-res-640-value="216" data-field-left-res-640-value="271" data-field-top-res-960-value="80" data-field-left-res-960-value="572" 
><div class='tn-atom'><a href="http://combasketteam.ru/order"style="color: inherit">Техническая поддержка<br></a></div> </div> <div class='t396__elem tn-elem tn-elem__1275852651564026170731' data-elem-id='1564026170731' data-elem-type='text' data-field-top-value="116" data-field-left-value="720" data-field-width-value="70" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="355" data-field-left-res-320-value="121" data-field-top-res-480-value="351" data-field-left-res-480-value="200" data-field-top-res-640-value="257" data-field-left-res-640-value="285" data-field-top-res-960-value="116" data-field-left-res-960-value="571" 
><div class='tn-atom'><a href="autr.php"style="color: inherit">Контакты<br></a></div> </div> <div class='t396__elem tn-elem tn-elem__1275852651564026287750' data-elem-id='1564026287750' data-elem-type='text' data-field-top-value="70" data-field-left-value="580" data-field-width-value="169" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-480-value="95" data-field-left-res-480-value="580" 
><div class='tn-atom'field='tn_text_1564026287750'></div> </div> <div class='t396__elem tn-elem tn-elem__1275852651564026470193' data-elem-id='1564026470193' data-elem-type='text' data-field-top-value="70" data-field-left-value="580" data-field-width-value="188" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-480-value="95" data-field-left-res-480-value="580" 
><div class='tn-atom'field='tn_text_1564026470193'></div> </div> <div class='t396__elem tn-elem tn-elem__1275852651564026597469' data-elem-id='1564026597469' data-elem-type='image' data-field-top-value="30" data-field-left-value="20" data-field-width-value="60" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-filewidth-value="1680" data-field-fileheight-value="1680" data-field-top-res-320-value="55" data-field-left-res-320-value="130" data-field-top-res-480-value="47" data-field-left-res-480-value="210" data-field-top-res-640-value="30" data-field-left-res-640-value="12" data-field-top-res-960-value="30" data-field-left-res-960-value="12" 
><a class='tn-atom' href="/" ><img class='tn-atom__img t-img' data-original='images/tild3162-6230-4666-b330-343530623633__combasketnewlogo_whi.png' imgfield='tn_img_1564026597469'></a></div> <div class='t396__elem tn-elem tn-elem__1275852651564026629614' data-elem-id='1564026629614' data-elem-type='text' data-field-top-value="50" data-field-left-value="94" data-field-width-value="79" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="115" data-field-left-res-320-value="121" data-field-top-res-480-value="107" data-field-left-res-480-value="201" data-field-top-res-640-value="95" data-field-left-res-640-value="10" data-field-top-res-960-value="50" data-field-left-res-960-value="86" 
><div class='tn-atom'field='tn_text_1564026629614'>NePROD</div> </div> <div class='t396__elem tn-elem tn-elem__1275852651564026948737' data-elem-id='1564026948737' data-elem-type='text' data-field-top-value="50" data-field-left-value="1085" data-field-width-value="70" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="564" data-field-left-res-320-value="125" data-field-top-res-480-value="560" data-field-left-res-480-value="205" data-field-top-res-640-value="90" data-field-left-res-640-value="560" data-field-top-res-960-value="50" data-field-left-res-960-value="855" 
><div class='tn-atom'field='tn_text_1564026948737'>Наверх<br></div> </div> <div class='t396__elem tn-elem tn-elem__1275852651564027196614' data-elem-id='1564027196614' data-elem-type='text' data-field-top-value="180" data-field-left-value="19" data-field-width-value="158" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="632" data-field-left-res-320-value="66" data-field-top-res-480-value="628" data-field-left-res-480-value="146" data-field-top-res-640-value="420" data-field-left-res-640-value="226" data-field-top-res-960-value="180" data-field-left-res-960-value="10" data-field-width-res-960-value="188" 
><div class='tn-atom'field='tn_text_1564027196614'>2023. All Rights reserved<br></div> </div> <div class='t396__elem tn-elem tn-elem__1275852651564027337563' data-elem-id='1564027337563' data-elem-type='text' data-field-top-value="205" data-field-left-value="460" data-field-width-value="179" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-480-value="230" data-field-left-res-480-value="460" 
><div class='tn-atom'field='tn_text_1564027337563'></div> </div> <div class='t396__elem tn-elem tn-elem__1275852651564027379553' data-elem-id='1564027379553' data-elem-type='text' data-field-top-value="200" data-field-left-value="19" data-field-width-value="169" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="652" data-field-left-res-320-value="66" data-field-top-res-480-value="648" data-field-left-res-480-value="146" data-field-top-res-640-value="440" data-field-left-res-640-value="226" data-field-top-res-960-value="200" data-field-left-res-960-value="10" data-field-width-res-960-value="188" 
><div class='tn-atom'field='tn_text_1564027379553'>Сделано с <span style="color: rgb(235, 151, 78);">☻</span> <a href="https://experts.tilda.cc/kseniya_yakovleva" target="_blank" style="color:rgb(249, 249, 249) !important;text-decoration: none;border-bottom: 1px solid rgb(249, 249, 249);box-shadow: inset 0px -0px 0px 0px rgb(249, 249, 249);-webkit-box-shadow: inset 0px -0px 0px 0px rgb(249, 249, 249);-moz-box-shadow: inset 0px -0px 0px 0px rgb(249, 249, 249);">Nazarukov Timophey</a></div> </div> <div class='t396__elem tn-elem tn-elem__1275852651564028213873' data-elem-id='1564028213873' data-elem-type='image' data-field-top-value="46" data-field-left-value="1158" data-field-width-value="20" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-animate-sbs-event="hover" data-animate-sbs-opts="[{'ti':'0','mx':'0','my':'0','sx':'1','sy':'1','op':'1','ro':'0','bl':'0','ea':'','dt':'0'},{'ti':1000,'mx':0,'my':-6,'sx':1,'sy':1,'op':'1','ro':'0','bl':'0','ea':'easeOut','dt':'0'}]" data-field-filewidth-value="691" data-field-fileheight-value="937" data-field-top-res-320-value="517" data-field-left-res-320-value="145" data-field-top-res-480-value="513" data-field-left-res-480-value="225" data-field-width-res-480-value="30" data-field-top-res-640-value="38" data-field-left-res-640-value="593" data-field-width-res-640-value="30" data-field-top-res-960-value="46" data-field-left-res-960-value="928" 
><a class='tn-atom' href="#up" ><img class='tn-atom__img t-img' data-original='images/tild6139-3563-4838-a361-303665653061__photo.png' imgfield='tn_img_1564028213873'></a></div> <div class='t396__elem tn-elem tn-elem__1275852651599395073156' data-elem-id='1599395073156' data-elem-type='text' data-field-top-value="45" data-field-left-value="380" data-field-width-value="169" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="175" data-field-left-res-320-value="62" data-field-width-res-320-value="197" data-field-top-res-480-value="171" data-field-left-res-480-value="131" data-field-width-res-480-value="217" data-field-top-res-640-value="52" data-field-left-res-640-value="236" data-field-top-res-960-value="45" data-field-left-res-960-value="330" 
><div class='tn-atom'><a href="http://combasketteam.ru/jersey-suits"style="color: inherit">Стеллажи</a></div> </div> <div class='t396__elem tn-elem tn-elem__1275852651599395073169' data-elem-id='1599395073169' data-elem-type='text' data-field-top-value="80" data-field-left-value="380" data-field-width-value="99" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="211" data-field-left-res-320-value="111" data-field-top-res-480-value="207" data-field-left-res-480-value="190" data-field-top-res-640-value="93" data-field-left-res-640-value="271" data-field-top-res-960-value="80" data-field-left-res-960-value="330" 
><div class='tn-atom'><a href="http://combasketteam.ru/clothing"style="color: inherit">Секции</a></div> </div> <div class='t396__elem tn-elem tn-elem__1275852651599395073177' data-elem-id='1599395073177' data-elem-type='text' data-field-top-value="116" data-field-left-value="380" data-field-width-value="70" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="247" data-field-left-res-320-value="125" data-field-top-res-480-value="243" data-field-left-res-480-value="204" data-field-top-res-640-value="134" data-field-left-res-640-value="285" data-field-top-res-960-value="116" data-field-left-res-960-value="330" 
><div class='tn-atom'><a href="http://combasketteam.ru/backpacks"style="color: inherit">Стойки</a></div> </div> <div class='t396__elem tn-elem tn-elem__1275852651599399715476' data-elem-id='1599399715476' data-elem-type='image' data-field-top-value="178" data-field-left-value="1047" data-field-width-value="37" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="427" data-field-left-res-320-value="141" data-field-top-res-480-value="423" data-field-left-res-480-value="221" data-field-top-res-640-value="330" data-field-left-res-640-value="301" data-field-top-res-960-value="178" data-field-left-res-960-value="813" 
><a class='tn-atom' href="http://vk.com/comfortbasket" rel="nofollow" target="_blank" ><img class='tn-atom__img t-img' data-original='images/tild3865-3363-4332-b433-623463303931__vk1.svg' imgfield='tn_img_1599399715476'></a></div> <div class='t396__elem tn-elem tn-elem__1275852651599399903615' data-elem-id='1599399903615' data-elem-type='image' data-field-top-value="179" data-field-left-value="948" data-field-width-value="35" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="428" data-field-left-res-320-value="21" data-field-top-res-480-value="424" data-field-left-res-480-value="111" data-field-top-res-640-value="331" data-field-left-res-640-value="191" data-field-top-res-960-value="179" data-field-left-res-960-value="714" 
><a class='tn-atom' href="https://api.whatsapp.com/send?phone=79223020749" rel="nofollow" target="_blank" ><img class='tn-atom__img t-img' data-original='images/tild3238-3164-4130-b338-666464663936__whats1.svg' imgfield='tn_img_1599399903615'></a></div> <div class='t396__elem tn-elem tn-elem__1275852651599399920662' data-elem-id='1599399920662' data-elem-type='image' data-field-top-value="179" data-field-left-value="1096" data-field-width-value="35" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="428" data-field-left-res-320-value="202" data-field-top-res-480-value="424" data-field-left-res-480-value="277" data-field-top-res-640-value="331" data-field-left-res-640-value="357" data-field-top-res-960-value="179" data-field-left-res-960-value="862" 
><a class='tn-atom' href="https://www.instagram.com/combasketteam/" rel="nofollow" target="_blank" ><img class='tn-atom__img t-img' data-original='images/tild6538-3034-4333-b961-396632343637__ig1.svg' imgfield='tn_img_1599399920662'></a></div> <div class='t396__elem tn-elem tn-elem__1275852651599399936487' data-elem-id='1599399936487' data-elem-type='image' data-field-top-value="178" data-field-left-value="1145" data-field-width-value="37" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="427" data-field-left-res-320-value="262" data-field-top-res-480-value="423" data-field-left-res-480-value="332" data-field-top-res-640-value="330" data-field-left-res-640-value="412" data-field-top-res-960-value="178" data-field-left-res-960-value="911" 
><a class='tn-atom' href="viber://chat?number=%2B79223020749" rel="nofollow" target="_blank" ><img class='tn-atom__img t-img' data-original='images/tild3261-3131-4435-a462-373138643937__viber1.svg' imgfield='tn_img_1599399936487'></a></div> <div class='t396__elem tn-elem tn-elem__1275852651599399948601' data-elem-id='1599399948601' data-elem-type='image' data-field-top-value="180" data-field-left-value="998" data-field-width-value="35" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="429" data-field-left-res-320-value="81" data-field-top-res-480-value="425" data-field-left-res-480-value="166" data-field-top-res-640-value="332" data-field-left-res-640-value="246" data-field-top-res-960-value="180" data-field-left-res-960-value="764" 
><a class='tn-atom' href="https://tmtr.me/@Cmbsktsupport" rel="nofollow" target="_blank" ><img class='tn-atom__img t-img' data-original='images/tild6162-6539-4139-b132-663265383932__tg1.svg' imgfield='tn_img_1599399948601'></a></div> </div> </div> <script>t_onReady(function () {
t_onFuncLoad('t396_init', function () {
t396_init('127585265');
});
});</script><!-- /T396 --></div><div id="rec229686638" class="r t-rec" style=" " data-animationappear="off" data-record-type="898" ><div class="t898 t898_animate"
style=""><div class="t898__wrapper"
style="right:30px;left:inherit;"><input type="checkbox" class="t898__btn_input" id="t898__btn_input_229686638" /><label for="t898__btn_input_229686638" class="t898__btn_label" style="background:#eb974e;"><svg role="presentation" class="t898__icon t898__icon-write" width="35" height="32" viewBox="0 0 35 32" xmlns="http://www.w3.org/2000/svg"><path d="M11.2667 12.6981H23.3667M11.2667 16.4717H23.3667M4.8104 23.5777C2.4311 21.1909 1 18.1215 1 14.7736C1 7.16679 8.38723 1 17.5 1C26.6128 1 34 7.16679 34 14.7736C34 22.3804 26.6128 28.5472 17.5 28.5472C15.6278 28.5472 13.8286 28.2868 12.1511 27.8072L12 27.7925L5.03333 31V23.8219L4.8104 23.5777Z" stroke="#ffffff" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" fill="none" /></svg><svg role="presentation" xmlns="http://www.w3.org/2000/svg" width="16" height="16" class="t898__icon t898__icon-close" viewBox="0 0 23 23"><g fillRule="evenodd"><path d="M10.314 -3.686H12.314V26.314H10.314z" transform="rotate(-45 11.314 11.314)" /><path d="M10.314 -3.686H12.314V26.314H10.314z" transform="rotate(45 11.314 11.314)" /></g></svg></label><!-- old soclinks --><a class="t898__icon t898__icon-telegram_wrapper t898__icon_link" href="https://t.me/Cmbsktsupport" target="_blank" rel="nofollow noopener noreferrer"><span class="t898__tooltip t-name t-name_xs">Telegram</span><svg role="presentation" width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M25 50C38.8071 50 50 38.8071 50 25C50 11.1929 38.8071 0 25 0C11.1929 0 0 11.1929 0 25C0 38.8071 11.1929 50 25 50Z" fill="#0087D0" /><path d="M36.11 13.0399L9.40999 22.7999C8.86999 22.9999 8.85999 23.7999 9.38999 24.0299L16.23 26.7199L18.78 34.4099C18.93 34.8199 19.47 34.9599 19.81 34.6799L23.73 31.1899L31.17 35.9099C31.55 36.1499 32.06 35.9399 32.15 35.5099L36.99 13.7599C37.09 13.2799 36.59 12.8699 36.11 13.0599V13.0399ZM20.03 28.1599L19.6 32.1199L17.53 26.0299L32.1 16.8699L20.03 28.1699V28.1599Z" fill="white" /></svg></a><a class="t898__icon t898__icon-whatsapp_wrapper t898__icon_link" href="https://wa.me/79223020749" target="_blank" rel="nofollow noopener noreferrer"><span class="t898__tooltip t-name t-name_xs">WhatsApp</span><svg role="presentation" width="50" height="50" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M25 50a25 25 0 100-50 25 25 0 000 50z" fill="#fff" /><path d="M26.1 12a12.1 12.1 0 00-10.25 18.53l.29.46-1.22 4.46 4.57-1.2.45.27a12.1 12.1 0 106.16-22.51V12zm6.79 17.22c-.3.85-1.72 1.62-2.41 1.72-.62.1-1.4.14-2.25-.14-.7-.22-1.37-.47-2.03-.77-3.59-1.57-5.93-5.24-6.1-5.48-.19-.24-1.47-1.97-1.47-3.76 0-1.79.93-2.67 1.25-3.03.33-.37.72-.46.96-.46.23 0 .47 0 .68.02.22 0 .52-.09.8.62l1.1 2.7c.1.18.16.4.04.64s-.18.39-.36.6c-.18.21-.38.47-.54.64-.18.18-.36.38-.15.74.2.36.92 1.55 1.98 2.52 1.37 1.23 2.52 1.62 2.88 1.8.35.18.56.15.77-.1.2-.23.9-1.05 1.13-1.42.24-.36.48-.3.8-.18.33.12 2.09 1 2.44 1.18.36.19.6.28.69.43.09.15.09.88-.21 1.73z" fill="#27D061" /><path d="M25 0a25 25 0 100 50 25 25 0 000-50zm1.03 38.37c-2.42 0-4.8-.6-6.9-1.76l-7.67 2 2.05-7.45a14.3 14.3 0 01-1.93-7.2c0-7.92 6.49-14.38 14.45-14.38a14.4 14.4 0 110 28.79z" fill="#27D061" /></svg></a><a class="t898__icon t898__icon-viber_wrapper t898__icon_link" href="viber://chat?number=%2B79223020749" target="_blank" rel="nofollow noopener noreferrer"><span class="t898__tooltip t-name t-name_xs">Viber</span><svg role="presentation" width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M25 43C34.9411 43 43 34.9411 43 25C43 15.0589 34.9411 7 25 7C15.0589 7 7 15.0589 7 25C7 34.9411 15.0589 43 25 43Z" fill="white" /><path d="M25 0C11.194 0 0 11.194 0 25C0 38.806 11.194 50 25 50C38.806 50 50 38.806 50 25C50 11.194 38.806 0 25 0ZM24.063 12.977C24.247 12.973 24.439 13.002 24.604 13.002C24.671 13.002 24.734 12.996 24.787 12.982C30.735 13.198 35.924 18.605 35.817 24.552C35.817 25.092 36.033 25.958 35.167 25.958C34.302 25.958 34.519 25.093 34.519 24.444C34.4326 23.7048 34.3034 22.9712 34.132 22.247C33.9787 21.5995 33.7772 20.9644 33.529 20.347C33.1967 19.5117 32.7468 18.7281 32.193 18.02C30.586 15.991 28.146 14.827 24.679 14.28C24.139 14.173 23.381 14.28 23.381 13.632C23.381 13.069 23.705 12.977 24.063 12.977V12.977ZM32.248 24.768C31.275 24.877 31.49 24.011 31.383 23.471C30.733 19.686 29.436 18.281 25.544 17.415C25.004 17.307 24.139 17.415 24.246 16.551C24.355 15.686 25.219 16.011 25.761 16.119C29.653 16.551 32.789 19.794 32.789 23.471C32.681 23.903 33.005 24.661 32.249 24.769L32.248 24.768ZM29.869 22.823C29.869 23.255 29.869 23.795 29.22 23.903C28.788 23.903 28.571 23.579 28.463 23.147C28.355 21.525 27.489 20.66 25.868 20.443C25.436 20.335 24.895 20.227 25.11 19.577C25.22 19.145 25.65 19.145 26.085 19.145C27.923 19.038 29.869 20.984 29.869 22.823ZM35.924 34.718C35.275 36.556 33.004 38.394 31.058 38.394C30.842 38.286 30.301 38.286 29.761 38.069C21.327 34.393 15.055 28.445 11.594 19.795C10.404 16.983 11.702 14.497 14.623 13.523C14.8797 13.4163 15.155 13.3613 15.433 13.3613C15.711 13.3613 15.9863 13.4163 16.243 13.523C17.542 13.956 20.677 18.39 20.786 19.687C20.893 20.767 20.136 21.308 19.488 21.741C18.19 22.607 18.19 23.796 18.731 24.985C20.029 27.797 22.191 29.635 24.894 30.933C25.868 31.365 26.841 31.365 27.49 30.283C28.679 28.445 30.193 28.445 31.815 29.635C32.572 30.175 33.436 30.716 34.193 31.365C35.276 32.23 36.573 32.986 35.924 34.717V34.718Z" fill="#935BBE" /></svg></a><a class="t898__icon t898__icon-vkontakte_wrapper t898__icon_link" href="https://vk.me/comfortbasket" target="_blank" rel="nofollow noopener noreferrer"><span class="t898__tooltip t-name t-name_xs">Vkontakte</span><svg role="presentation" width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M25 50C38.8071 50 50 38.8071 50 25C50 11.1929 38.8071 0 25 0C11.1929 0 0 11.1929 0 25C0 38.8071 11.1929 50 25 50Z" fill="#47668D" /><path d="M39.8399 32.3501C38.9703 30.9857 37.8941 29.7645 36.6499 28.7301L36.6199 28.7001L36.5999 28.6801L36.5799 28.6701H36.5699C36.1122 28.269 35.675 27.8451 35.2599 27.4001C34.9299 26.9801 34.8599 26.5601 35.0299 26.1401C35.1599 25.8201 35.6499 25.1401 36.4899 24.1101L37.5399 22.7901C39.3999 20.4101 40.1999 18.8901 39.9599 18.2301L39.8599 18.0701C39.7899 17.9701 39.6299 17.8901 39.3599 17.8201C39.0225 17.7395 38.6726 17.7259 38.3299 17.7801L33.6799 17.8101C33.5017 17.7922 33.3217 17.8092 33.1499 17.8601L33.0599 17.9001L32.9999 17.9501C32.8498 18.0601 32.7324 18.2087 32.6599 18.3801C31.9272 20.2055 30.9806 21.9376 29.8399 23.5401C29.4584 24.149 28.9667 24.6815 28.3899 25.1101C28.1999 25.2501 28.0599 25.3101 27.9699 25.2901L27.6899 25.2201C27.5399 25.1301 27.4199 25.0001 27.3299 24.8401C27.2299 24.6801 27.1699 24.4801 27.1399 24.2401C27.0728 23.7867 27.056 23.3272 27.0899 22.8701L27.1099 22.2101C27.1038 21.4197 27.1239 20.6292 27.1699 19.8401C27.1899 19.5701 27.1899 19.2901 27.1899 18.9901C27.2181 18.577 27.1388 18.1636 26.9599 17.7901C26.8914 17.6327 26.7762 17.5001 26.6299 17.4101C26.4611 17.3164 26.2791 17.2489 26.0899 17.2101C25.5199 17.0801 24.7899 17.0101 23.9099 17.0101C21.9099 16.9801 20.6299 17.1101 20.0599 17.3701C19.8299 17.4901 19.6299 17.6401 19.4399 17.8401C19.2399 18.0701 19.2199 18.1901 19.3599 18.2101C20.0099 18.3101 20.4599 18.5301 20.7299 18.8801L20.8299 19.0701C20.9099 19.2001 20.9799 19.4401 21.0599 19.7701C21.3319 21.2006 21.3319 22.6696 21.0599 24.1001C21.0083 24.4885 20.8643 24.8589 20.6399 25.1801C20.6192 25.2121 20.592 25.2394 20.5599 25.2601C20.4199 25.3101 20.2699 25.3301 20.1199 25.3301C19.9699 25.3301 19.7899 25.2601 19.5699 25.1201C19.3235 24.9475 19.0986 24.7461 18.8999 24.5201C18.6699 24.2701 18.4099 23.9201 18.1199 23.4601C17.8199 23.0001 17.5199 22.4601 17.2199 21.8401L16.9599 21.3901C16.453 20.4536 15.9859 19.4961 15.5599 18.5201C15.4831 18.3152 15.343 18.14 15.1599 18.0201L15.0899 17.9801C14.8962 17.8646 14.6825 17.7866 14.4599 17.7501L10.0299 17.7801C9.57994 17.7801 9.26994 17.8801 9.10994 18.0801L9.04994 18.1701C9.01321 18.2446 8.996 18.3272 8.99994 18.4101C8.99994 18.5301 9.02994 18.6701 9.09994 18.8301C10.2449 21.4412 11.6098 23.9503 13.1799 26.3301C14.181 27.8114 15.2836 29.2215 16.4799 30.5501L16.8899 30.9201C17.1499 31.1701 17.5299 31.4601 18.0299 31.8101C18.5299 32.1601 19.0799 32.5001 19.6899 32.8301C21.0679 33.5631 22.6093 33.9347 24.1699 33.9101H26.0299C26.3999 33.8801 26.6899 33.7701 26.8799 33.5701L26.9499 33.4901C26.9899 33.4301 27.0299 33.3301 27.0699 33.2101C27.1099 33.0801 27.1199 32.9301 27.1199 32.7801C27.1071 32.3771 27.144 31.9741 27.2299 31.5801C27.3099 31.2201 27.3999 30.9501 27.4999 30.7701C27.6532 30.4968 27.8691 30.2637 28.1299 30.0901L28.2599 30.0301C28.5099 29.9501 28.8199 30.0301 29.1599 30.2701C29.5199 30.5201 29.8399 30.8201 30.1599 31.1701C30.4599 31.5301 30.8299 31.9301 31.2599 32.3701C31.6899 32.8201 32.0599 33.1501 32.3899 33.3701L32.7099 33.5601C32.9199 33.6801 33.2099 33.7901 33.5499 33.9001C33.8899 34.0001 34.1899 34.0301 34.4499 33.9701L38.5799 33.9101C38.9899 33.9101 39.3099 33.8501 39.5399 33.7101C39.7599 33.5901 39.8999 33.4501 39.9399 33.2901C39.9799 33.1401 39.9899 32.9601 39.9399 32.7601C39.9099 32.5601 39.8699 32.4301 39.8399 32.3601V32.3501Z" fill="white" /></svg></a><a class="t898__icon t898__icon-mail_wrapper t898__icon_link" href="mailto:combasket.info@mail.ru" target="_blank" rel="nofollow noopener noreferrer"><span class="t898__tooltip t-name t-name_xs">Mail</span><svg role="presentation" width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M25 43C34.9411 43 43 34.9411 43 25C43 15.0589 34.9411 7 25 7C15.0589 7 7 15.0589 7 25C7 34.9411 15.0589 43 25 43Z" fill="white" /><path d="M25 0C11.2 0 0 11.2 0 25C0 38.8 11.2 50 25 50C38.8 50 50 38.8 50 25C50 11.2 38.84 0 25 0ZM38.8 14.96L25 27.18L11.2 14.96H38.8ZM9.32 16.68L18.76 25L9.33 33.32V16.68H9.32ZM11.2 35.04L20.63 26.72L24.13 29.87C24.3744 30.0647 24.6776 30.1707 24.99 30.1707C25.3024 30.1707 25.6056 30.0647 25.85 29.87L29.35 26.72L38.78 35.04H11.21H11.2ZM40.66 33.32L31.29 25L40.72 16.68V33.32H40.67H40.66Z" fill="#168DE2" /></svg></a><!-- old soclinks --></div></div><style>@media screen and (max-width: 960px) {
#rec229686638 .t898 .t898__wrapper {
bottom:100px !important; right:25px !important;left: initial !important; }
}</style><script type="text/javascript">t_onReady(function() {
t_onFuncLoad('t898_init', function() {
t898_init('229686638');
});
});</script></div><div id="rec229687189" class="r t-rec" style=" " data-animationappear="off" data-record-type="269" ><!-- t139 --><div class="t139"></div></div><div id="rec229686640" class="r t-rec" style=" " data-animationappear="off" data-record-type="269" ><!-- t139 --><div class="t139"><script src="//code.jivosite.com/widget.js" data-jv-id="AHGKgWWNAG" async></script></div></div><div id="rec229686639" class="r t-rec" style=" " data-animationappear="off" data-record-type="131" ><!-- T123 --><div class="t123" ><div class="t-container_100 "><div class="t-width t-width_100 ">

			<link rel="stylesheet" type="text/css" media="screen" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jQuery-viewport-checker/1.8.7/jquery.viewportchecker.min.js"></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jQuery-viewport-checker/1.8.8/jquery.viewportchecker.min.js"></script>
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>-->
<style type=text/css>
    .hidden {opacity: 0;}
    .visible {opacity: 1;}
    
    /*цвет мобильного меню*/
    @media screen and (max-width: 980px) {
        .t228__mobile {
            background-color: #b2c0c4;
        }
    }
</style>
			 
			
</div> </div></div></div><div id="rec229686641" class="r t-rec" style=" " data-animationappear="off" data-record-type="131" ><!-- T123 --><div class="t123" style="position: absolute; width: 1px; height: 1px; opacity:0;"><div class="t-container_100 "><div class="t-width t-width_100 ">

			<script>
    $(document).ready(function () {
        
        // добавление лого для мобильного меню
        
        $('div.t228__mobile_container')[0].innerHTML = '<div><img src=images/tild3330-6637-4539-b063-383039626131__combasketnewlogo_gre.png width="35" height="35"/></div> <div class="t228__burger"> <span></span> <span></span> <span></span> <span></span> </div>';
    
    })
</script>

			 
			
</div> </div></div></div><div id="rec229686643" class="r t-rec" style=" " data-animationappear="off" data-record-type="131" ><!-- T123 --><div class="t123" style="position: absolute; width: 1px; height: 1px; opacity:0;"><div class="t-container_100 "><div class="t-width t-width_100 ">

			<style>
    /*подсветка ссылок в футере оранжевым при наведении*/
    #rec119095532 a:hover{
     color: #eb974e !important;
      transition: 0,6s;
    }
    #rec119095941 a:hover{
     color: #eb974e !important;
      transition: 0,6s;
    }
    #rec119096242 a:hover{
     color: #eb974e !important;
      transition: 0,6s;
    }
    #rec119096030 a:hover{
     color: #eb974e !important;
      transition: 0,6s;
    }
</style>
			 
			
</div> </div></div></div><div id="rec119498931" class="r t-rec" style=" " data-record-type="270" ><div class="t270"></div><script>t_onReady(function () {
var hash = window.location.hash;
t_onFuncLoad('t270_scroll', function () {
t270_scroll(hash, -3);
});
setTimeout(function() {
var curPath = window.location.pathname;
var curFullPath = window.location.origin + curPath;
var recs = document.querySelectorAll('.r');
Array.prototype.forEach.call(recs, function(rec) {
var selects = 'a[href^="#"]:not([href="#"]):not(.carousel-control):not(.t-carousel__control):not([href^="#price"]):not([href^="#popup"]):not([href^="#prodpopup"]):not([href^="#order"]):not([href^="#!"]):not([target="_blank"]),' + 
'a[href^="' + curPath + '#"]:not([href*="#!/tproduct/"]):not([href*="#!/tab/"]):not([href*="#popup"]):not([target="_blank"]),' +
'a[href^="' + curFullPath + '#"]:not([href*="#!/tproduct/"]):not([href*="#!/tab/"]):not([href*="#popup"]):not([target="_blank"])';
var elements = rec.querySelectorAll(selects);
Array.prototype.forEach.call(elements, function(element) {
element.addEventListener('click', function (event) {
event.preventDefault();
var hash = this.hash.trim();
t_onFuncLoad('t270_scroll', function () {
t270_scroll(hash, -3);
});
});
});
});
if (document.querySelectorAll('.js-store').length > 0 || document.querySelectorAll('.js-feed').length > 0) {
t_onFuncLoad('t270_scroll', function () {
t270_scroll(hash, -3, 1);
});
}
}, 500);
setTimeout(function() {
var hash = window.location.hash;
if (hash && document.querySelectorAll('a[name="' + hash.slice(1) + '"]').length > 0) {
if (window.isMobile) {
t_onFuncLoad('t270_scroll', function () {
t270_scroll(hash, 0);
});
} else {
t_onFuncLoad('t270_scroll', function () {
t270_scroll(hash, 0);
});
}
}
}, 1000);
window.addEventListener('popstate', function() {
var hash = window.location.hash;
if (hash && document.querySelectorAll('a[name="' + hash.slice(1) + '"]').length > 0) {
if (window.isMobile) {
t_onFuncLoad('t270_scroll', function () {
t270_scroll(hash, 0);
});
} else {
t_onFuncLoad('t270_scroll', function () {
t270_scroll(hash, 0);
});
}
}
});
});</script></div></div><!--/footer--></div><!--/allrecords--><!-- Stat --><script type="text/javascript">if (! window.mainTracker) { window.mainTracker = 'tilda'; }
window.tildastatscroll='yes'; 
setTimeout(function(){ (function (d, w, k, o, g) { var n=d.getElementsByTagName(o)[0],s=d.createElement(o),f=function(){n.parentNode.insertBefore(s,n);}; s.type = "text/javascript"; s.async = true; s.key = k; s.id = "tildastatscript"; s.src=g; if (w.opera=="[object Opera]") {d.addEventListener("DOMContentLoaded", f, false);} else { f(); } })(document, window, '9f9250201f455345af2fc8c81774e699','script','js/tilda-stat-1.0.min.js');
}, 2000); </script></body></html>