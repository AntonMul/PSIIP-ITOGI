
<div>
    <a href="autr.php" class="autrz">Войти</a>
</div>
<?php
 $msg = $_COOKIE["login"];
 if($msg!=null)
 {   
     echo "<a class='cabin'>"."<a href='cab.php' class='cabin'>".$msg."</a>"."</a>";
 } ?>
 
<!DOCTYPE html><html>
    <head><meta charset="utf-8" /><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="style2.css">
<body>
<div class="container">
<div class="block-row">
 <?php
        $link=mysqli_connect("localhost", "root", "root", "kyrsach");
        $query = "select cena, opis,status from info";
        if($result =$link->query($query))
        {
            $rowsCount = $result->num_rows;
        }
        
        foreach($result as $row)
        {
       
                 
    echo "<div class='block'>";
            echo "<div class='status'>";
        echo "<h2>".$row["status"]."</h2>";

        echo "<div class='opis'>";
            echo "<p>".$row["opis"]."</p>";
        echo "</div>";

        echo  "<div class='cena'>";
            echo "<b>".$row["cena"]."</b>";
        echo "</div>";
    echo "</div>";
        }
        ?>
        </div>
    </div>
    <div class="block-row">
        <div class="container">
        <?php
        $link=mysqli_connect("localhost", "root", "root", "kyrsach");
        $query = "select name from proizv";
        if($result =$link->query($query))
        {
            $rowsCount = $result->num_rows;
        }
        foreach($result as $row)
        {
    echo "<div class='block2'>";
        echo "<h2>".$row["name"]."</h2>";
    echo "</div>";
        }
        ?>
        </div>
    </div>
</body>
    