<?require 'tpl/header.php';?>
<?require 'tpl/body.php';?>
<?require 'tpl/footer.php';?>