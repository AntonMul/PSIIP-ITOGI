<?require 'tpl/header.php';?>
<?require 'tpl/body.php';?>
<?require 'tpl/sign-in.php';?>
<?require 'tpl/footer.php';?>