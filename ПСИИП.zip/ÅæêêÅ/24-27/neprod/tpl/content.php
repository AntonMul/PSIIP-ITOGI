 <!-- content -->
 <?
      $link=mysqli_connect("localhost", "root", "root", "neprod");
      $query = "SELECT name, status, text, category FROM product";
      $queryprice = "SELECT cost FROM price";
      if($result =$link->query($query))
      {
          $rowsCount = $result->num_rows;
      }
      if($result2 =$link->query($queryprice))
      {
          $rowsCount2 = $result2->num_rows;
      }

      foreach($result as $row):?>
      
          
 <div class="container mt-5">
     
    <h3><? echo $row['category'];?></h3>
            <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-header py-3">
            <h4 class="my-0 fw-normal"><?php echo $row['status'];?></h4>
          </div>
          <div class="card-body">
          <?php  foreach($result2 as $row2): ?>
            <h1 class="card-title pricing-card-title"><small class="text-muted fw-light"><?= $row2['cost'] ?>/BYN</small></h1><!-- ERROR_PRICE -->
            <?php endforeach; ?> 
            <h2><?echo $row['name'];?></h2>
            <ul class="list-unstyled mt-3 mb-4">
              <li><?echo $row['text'];?></li>
            </ul>
            <button type="button" class="w-100 btn btn-lg btn-primary">Приобрести</button>
          </div>
        </div>
      </div>
      <?php endforeach; ?> 
      <!-- /content -->